package com.dc.governance.metadata.impls.expression;

import com.dc.esb.container.core.data.IServiceDataObject;
import com.dc.governance.metadata.impls.SDO;
import com.dc.governance.metadata.impls.expression.function.DefaultFunction;
import com.dc.governance.metadata.interfaces.expression.IExpressionEngine;
import org.apache.commons.jexl2.JexlContext;
import org.apache.commons.jexl2.MapContext;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class JEXLExpressionImplTest {

    private JEXLExpressionImpl jexlExpressionImplUnderTest;
    @Mock
    private Logger logger;
    @Before
    public void setUp() throws Exception {
        logger = mock(Logger.class);
        when(logger.isDebugEnabled()).thenReturn(true);
        when(logger.isInfoEnabled()).thenReturn(true);
        when(logger.isErrorEnabled()).thenReturn(true);
        Field logField = JEXLExpressionImpl.class.getDeclaredField("logger");
        logField.setAccessible(true);
        logField.set(null, logger);
        jexlExpressionImplUnderTest = (JEXLExpressionImpl) JEXLExpressionImpl.getExpressionEngine();
    }

    @Test
    public void testGetExpressionEngine() {
        // Setup
        // Run the test
        final IExpressionEngine result = JEXLExpressionImpl.getExpressionEngine();

        // Verify the results
    }

    @Test
    public void testEvulate1() {
        // Setup
        final IServiceDataObject sdo = new SDO();
        sdo.set("A","2");
        sdo.set("B","2");
        // Run the test
        final Integer result = jexlExpressionImplUnderTest.evulate("1+1-(${A}-${B})", sdo, Integer.class);
        // Verify the results
        assertThat(result).isEqualTo(2);
        final String result2 = jexlExpressionImplUnderTest.evulate("'C'", sdo, String.class);
        assertThat(result2).isEqualTo("C");
    }

    @Test
    public void testEvulate2() {
        // Setup
        final JexlContext context = new MapContext();
        context.set("A","2");
        context.set("B","2");

        // Run the test
        final Integer result = jexlExpressionImplUnderTest.evulate("1+1-(2-2)", context,Integer.class);

        // Verify the results
        assertThat(result).isEqualTo(2);
    }

//    @Test
//    public void testMain() {
//        // Setup
//        // Run the test
//        JEXLExpressionImpl.main(new String[]{"args"});
//
//        // Verify the results
//    }

    @Test
    public void testEvulate3() {
        // Setup
        final Map<String, Object> values = Map.ofEntries(Map.entry("A", "1"),Map.entry("B", "1"));

        // Run the test
        final Integer result = jexlExpressionImplUnderTest.evulate("(1+1)+${A}+${B}", values, Integer.class);

        // Verify the results
        assertThat(result).isEqualTo(4);
        // Run the test
        final String result2 = jexlExpressionImplUnderTest.evulate("'A'", values, String.class);

        // Verify the results
        assertThat(result2).isEqualTo("A");
        // Run the test
        final List<String> result3 = jexlExpressionImplUnderTest.evulate("${C}", values, List.class);

        // Verify the results
        assertThat(result3.toString()).isEqualTo("[]");
    }
}
