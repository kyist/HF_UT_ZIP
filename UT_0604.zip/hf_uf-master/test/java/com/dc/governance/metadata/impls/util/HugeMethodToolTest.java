package com.dc.governance.metadata.impls.util;

import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedList;

public class HugeMethodToolTest {

    private Method getRefactMethod;
    private Method refactMethod;
    private Method arrayLevelsMethod;
    private Method refactArrayMethod;

    @Before
    public void setUp() throws Exception {
        // 获取私有方法 getRefactMethod
        getRefactMethod = HugeMethodTool.class.getDeclaredMethod(
                "getRefactMethod",
                String.class,
                String.class,
                String.class,
                String[].class
        );
        getRefactMethod.setAccessible(true);

        // 获取私有方法 _refact
        refactMethod = HugeMethodTool.class.getDeclaredMethod(
                "_refact",
                String.class,
                StringBuffer.class,
                String.class,
                String.class,
                String[].class
        );
        refactMethod.setAccessible(true);

        // 获取私有方法 getArrayLevels
        arrayLevelsMethod = HugeMethodTool.class.getDeclaredMethod(
                "getArrayLevels",
                String.class
        );
        arrayLevelsMethod.setAccessible(true);

        // 获取私有方法 _refactArray
        refactArrayMethod = HugeMethodTool.class.getDeclaredMethod(
                "_refactArray",
                String.class,
                StringBuffer.class,
                String.class,
                String.class,
                LinkedList.class,
                String.class
        );
        refactArrayMethod.setAccessible(true);
    }

    // ---------------------- 测试 getRefactMethod 方法 ----------------------

    @Test
    public void testGetRefactMethod_BasicGeneration() throws InvocationTargetException, IllegalAccessException {
        String arrayXpath = "/test/path";
        String methodName = "testMethod";
        String methodBody = "System.out.println(\"Hello World\");";
        String[] _arrayVariableIndex = {"index1", "index2"};

        StringBuffer result = (StringBuffer) getRefactMethod.invoke(null, arrayXpath, methodName, methodBody, _arrayVariableIndex);

        Assert.assertNotNull(result);
        Assert.assertTrue(result.toString().contains("private void testMethod"));
        Assert.assertTrue(result.toString().contains(methodBody));
        Assert.assertTrue(result.toString().contains("int index1,int index2"));
        Assert.assertTrue(result.toString().contains("throws UnsupportedEncodingException, IOException, PackerException"));
        Assert.assertTrue(result.toString().contains("try{") && result.toString().contains("catch(Exception e){"));
    }

    @Test
    public void testGetRefactMethod_WithSingleTag() throws InvocationTargetException, IllegalAccessException {
        String arrayXpath = "/test/path";
        String methodName = "testMethod";
        String objectLabel = "/*TAG_/test/path";
        String methodBody = "before tag" + objectLabel + "*/code inside" + objectLabel + "*/after tag";
        String[] _arrayVariableIndex = {"index"};

        StringBuffer result = (StringBuffer) getRefactMethod.invoke(null, arrayXpath, methodName, methodBody, _arrayVariableIndex);

        Assert.assertNotNull(result);
        Assert.assertTrue(result.toString().contains("private void testMethod0"));
        Assert.assertTrue(result.toString().contains("private void testMethod("));
        Assert.assertTrue(result.toString().contains("code inside"));
        Assert.assertTrue(result.toString().contains("testMethod0(out,sdo"));
    }

    @Test
    public void testGetRefactMethod_WithMultipleTags() throws InvocationTargetException, IllegalAccessException {
        String arrayXpath = "/test/path";
        String methodName = "testMethod";
        String objectLabel = "/*TAG_/test/path";
        String forNumber = "forNum";
        String methodBody = "before tag" +
                objectLabel + "*/@" + forNumber + "*//**/" +
                "code inside 1" + objectLabel + "*/code inside 2" + objectLabel + "*/after tag";
        String[] _arrayVariableIndex = {"idx"};

        StringBuffer result = (StringBuffer) getRefactMethod.invoke(null, arrayXpath, methodName, methodBody, _arrayVariableIndex);

        Assert.assertNotNull(result);
        Assert.assertTrue(result.toString().contains("private void testMethod0"));
        Assert.assertTrue(result.toString().contains("private void testMethod1"));
        Assert.assertTrue(result.toString().contains("private void testMethod("));
        Assert.assertTrue(result.toString().contains("testMethod0(out,sdo"));
        Assert.assertTrue(result.toString().contains("testMethod1(out,sdo"));
        Assert.assertTrue(result.toString().contains("forNum"));
    }

    @Test
    public void testGetRefactMethod_WithoutArrayIndex() throws InvocationTargetException, IllegalAccessException {
        String arrayXpath = "/test/path";
        String methodName = "testMethod";
        String methodBody = "System.out.println(\"Hello World\");";
        String[] _arrayVariableIndex = new String[0];

        StringBuffer result = (StringBuffer) getRefactMethod.invoke(null, arrayXpath, methodName, methodBody, _arrayVariableIndex);

        Assert.assertNotNull(result);
        Assert.assertTrue(result.toString().contains("private void testMethod"));
        Assert.assertTrue(result.toString().contains(methodBody));
        Assert.assertFalse(result.toString().contains("int "));
        Assert.assertTrue(result.toString().contains("throws UnsupportedEncodingException, IOException, PackerException"));
    }

    // ---------------------- 测试 _refact 方法 ----------------------

    @Test
    public void testRefact_MethodExtraction() throws InvocationTargetException, IllegalAccessException {
        String arrayXpath = "/test/path";
        StringBuffer hugeCode = new StringBuffer("some code <!--BEGIN-->methodBody<!--END--> more code");
        String beginFlag = "<!--BEGIN-->";
        String endFlag = "<!--END-->";
        String[] _arrayVariableIndex = {"index1", "index2"};

        StringBuffer result = (StringBuffer) refactMethod.invoke(null, arrayXpath, hugeCode, beginFlag, endFlag, _arrayVariableIndex);

        Assert.assertNotNull(result);
        Assert.assertTrue(result.toString().contains("methodBody"));
        Assert.assertTrue(result.toString().contains("int index1,int index2"));
    }

    // ---------------------- 测试 getArrayLevels 方法 ----------------------

    @Test
    public void testGetArrayLevels_WithMultipleLevels() throws InvocationTargetException, IllegalAccessException {
        String xpath = "/level1[\"index1\"][\"index2\"][\"index3\"]";

        String[] result = (String[]) arrayLevelsMethod.invoke(null, xpath);

        Assert.assertNotNull(result);
    }

    @Test
    public void testGetArrayLevels_WithNoLevels() throws InvocationTargetException, IllegalAccessException {
        String xpath = "/level1";

        String[] result = (String[]) arrayLevelsMethod.invoke(null, xpath);

        Assert.assertNotNull(result);
        Assert.assertEquals(0, result.length);
    }

    @Test
    public void testGetArrayLevels_WithNullInput() throws InvocationTargetException, IllegalAccessException {
        String[] result = (String[]) arrayLevelsMethod.invoke(null, (Object) null);

        Assert.assertNotNull(result);
        Assert.assertEquals(0, result.length);
    }

    // ---------------------- 测试 _refactArray 方法 ----------------------

    @Test
    public void testRefactArray_WithValidArrayLevels() throws InvocationTargetException, IllegalAccessException {
        String arrayXpath = "/test/path";
        StringBuffer hugeCode = new StringBuffer("some code <!--BEGIN-->methodBody<!--END--> more code");
        String beginFlag = "<!--BEGIN-->";
        String endFlag = "<!--END-->";
        String arrayXpathWithIndex = "/test/path[\"index1\"][\"index2\"]";
        LinkedList<StringBuffer> refactMethods = new LinkedList<>();

        StringBuffer result = (StringBuffer) refactArrayMethod.invoke(null, arrayXpath, hugeCode, beginFlag, endFlag, refactMethods, arrayXpathWithIndex);

        Assert.assertEquals(hugeCode, result);
        Assert.assertFalse(refactMethods.isEmpty());
        Assert.assertTrue(refactMethods.getFirst().toString().contains("private void"));
    }

    @Test
    public void testRefactArray_WithEmptyArrayLevels() throws InvocationTargetException, IllegalAccessException {
        String arrayXpath = "/test/path";
        StringBuffer hugeCode = new StringBuffer("some code <!--BEGIN-->methodBody<!--END--> more code");
        String beginFlag = "<!--BEGIN-->";
        String endFlag = "<!--END-->";
        String arrayXpathWithIndex = "/test/path";
        LinkedList<StringBuffer> refactMethods = new LinkedList<>();

        StringBuffer result = (StringBuffer) refactArrayMethod.invoke(null, arrayXpath, hugeCode, beginFlag, endFlag, refactMethods, arrayXpathWithIndex);

        Assert.assertEquals(hugeCode, result);
        Assert.assertFalse(refactMethods.isEmpty());
        Assert.assertTrue(refactMethods.getFirst().toString().contains("private void"));
    }
}
