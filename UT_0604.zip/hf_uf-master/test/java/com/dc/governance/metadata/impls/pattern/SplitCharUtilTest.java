package com.dc.governance.metadata.impls.pattern;
import org.junit.Test;

import org.assertj.core.api.Assertions;

public class SplitCharUtilTest {

    @Test
    public void testMultipleHexValues() {
        // TC1: 多个十六进制值
        String input = "0x7f,0x08";
        byte[] expected = new byte[]{(byte) 0x7f, (byte) 0x08};
        Assertions.assertThat(SplitCharUtil.splitCharToByte(input)).isEqualTo(expected);
    }

    @Test
    public void testMultipleChars() {
        // TC2: 多个普通字符
        String input = "0x61,0x62,0x63";
        byte[] expected = new byte[]{'a', 'b', 'c'};
        Assertions.assertThat(SplitCharUtil.splitCharToByte(input)).isEqualTo(expected);
    }

    @Test
    public void testSingleHexValue() {
        // TC3: 单个十六进制值
        String input = "0x41";
        byte[] expected = new byte[]{(byte) 0x41};
        Assertions.assertThat(SplitCharUtil.splitCharToByte(input)).isEqualTo(expected);
    }

    @Test
    public void testSingleString() {
        // TC4: 单个普通字符串
        String input = "abc";
        byte[] expected = "abc".getBytes();
        Assertions.assertThat(SplitCharUtil.splitCharToByte(input)).isEqualTo(expected);
    }

    @Test
    public void testEmptySplit() {
        // TC5: 空元素
        String input = "00,00,";
        byte[] expected = new byte[2]; // 默认初始化为0
        Assertions.assertThat(SplitCharUtil.splitCharToByte(input)).isEqualTo(expected);
    }

    @Test
    public void testNullOrEmptyInput() {
        // TC7: 空字符串
        String input = "";
        byte[] expected = new byte[0];
        Assertions.assertThat(SplitCharUtil.splitCharToByte(input)).isEqualTo(expected);
    }

}
