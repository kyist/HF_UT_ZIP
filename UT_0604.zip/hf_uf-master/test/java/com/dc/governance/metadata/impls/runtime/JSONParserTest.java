package com.dc.governance.metadata.impls.runtime;

import com.dc.esb.container.core.data.IServiceDataObject;
import com.dc.esb.container.core.sclite.IBaseContext;

import com.dc.esb.container.sclite.PoolableBaseContext;
import com.dc.esb.container.service.FileUtil;
import com.dc.governance.metadata.impls.SDO;
import com.dc.governance.metadata.interfaces.exception.ParserException;
import com.dc.governance.metadata.interfaces.parser.IMetaNodeAttr;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class JSONParserTest {


    private JSONParser jsonParserUnderTest;
    private static final String content = "{\n" + "    \"list\": [\n" + "        \"Item 1\",\n" + "        \"Item 2\"\n" + "    ],\n" + "    \"obj\": {\n" + "        \"name\": \"John Doe\",\n" + "        \"age\": \"30\",\n" + "        \"isStudent\": \"false\"\n" + "    },\n" + "    \"message\": \"Hello, World!\",\n" + "    \"isActive\": \"true\",\n" + "\t\"count\": 2\n" + "}";
    private Object invokeMethod(Object jsonParserUnderTest,String methodName, Object... objs) {
        Class[] classes = new Class[objs.length];
        if (objs.length > 0){
            for (int i = 0; i < objs.length; i++) {
                classes[i] = objs[i].getClass();
            }
        }
        Method method;
        try {
            method = JSONParser.class.getDeclaredMethod(methodName, classes);
            method.setAccessible(true);
            return method.invoke(jsonParserUnderTest, objs);
        } catch (Exception e) {

        }
        return null;
    }

    @Before
    public void setUp() throws Exception {

        jsonParserUnderTest = new JSONParser();
        jsonParserUnderTest.init(content.getBytes());
        Properties properties = new Properties();
        properties.setProperty("metadataid","message");
        properties.setProperty("type","s");
        jsonParserUnderTest.xpath_nodeAttr.put("message",properties);
    }

        @Test
        public void testInit1() throws Exception {

            // Setup
            // Run the test
            jsonParserUnderTest.init(content.getBytes());

            // Verify the results
        }

    @Test
    public void testInit1_ThrowsParserException() {
        // Setup
        // Run the test
        assertThatThrownBy(() -> jsonParserUnderTest.init("content".getBytes())).isInstanceOf(ParserException.class);
    }

    @Test
    public void testInit2() throws Exception {
        // Setup
        // Run the test
        jsonParserUnderTest.init(content.getBytes(), false);

        // Verify the results
    }

//    @Test
//    public void testInit2_ThrowsParserException() throws ParserException {
//        // Setup
//        // Run the test
//        jsonParserUnderTest.init("{aa:''}".getBytes(), false);
//        assertThatThrownBy(() -> jsonParserUnderTest.init("{aa:''}".getBytes(), false)).isInstanceOf(
//                ParserException.class);
//    }

    @Test
    public void testParse() throws Exception {
        // Setup
        // Run the test
        final Map<String, Object> result = jsonParserUnderTest.parse("root");
        assertThat(result.size()).isEqualTo(8);
        String arr = "[\n" + "    {\n" + "        \"name\": \"Anna Doe\",\n" + "        \"age\": \"15\",\n" + "        \"isStudenta\": \"true\",\n" + "        \"isStudent\": \"t\"\n" + "    },\n" + "    {\n" + "        \"name\": \"John Doe\",\n" + "        \"age\": \"30\",\n" + "        \"isStudenta\": \"false\",\n" + "        \"isStudent\": \"n\"\n" + "    }\n" + "]";
        Field scanner = JSONParser.class.getDeclaredField("scanner");
        scanner.setAccessible(true);
        JSONScanner jsonScanner = new JSONScanner(arr.getBytes());
        scanner.set(jsonParserUnderTest, jsonScanner);
        final Map<String, Object> result2 = jsonParserUnderTest.parse("root");
        assertThat(result.size()).isEqualTo(16);
//        Method parserArray = JSONParser.class.getDeclaredMethod("parserArray", String.class);
//        parserArray.setAccessible(true);
//        jsonScanner.reset();
//        Field scanner2= JSONParser.class.getDeclaredField("scanner");
//        scanner2.setAccessible(true);
//        JSONScanner jsonScanner2= new JSONScanner(arr.getBytes());
//        scanner2.set(jsonParserUnderTest, jsonScanner2);
//        parserArray.invoke(jsonParserUnderTest,arr);
        // Verify the results
    }
    @Test
    public void testParse_ThrowsParserException() throws Exception {
        // Setup
        // Run the test
        String arr = "AAA:BBB";

        Field scanner = JSONParser.class.getDeclaredField("scanner");
        scanner.setAccessible(true);
        JSONScanner jsonScanner = new JSONScanner(arr.getBytes());
        scanner.set(jsonParserUnderTest, jsonScanner);

        assertThatThrownBy(() -> jsonParserUnderTest.parse("root")).isInstanceOf(Exception.class);
        // Verify the results
    }

    @Test
    public void testGetSDO() throws Exception {
        // Setup
        final Map<String,String> values = new HashMap();
        values.put("A","A");
        final IBaseContext context = null;
        Properties properties = new Properties();
        properties.setProperty("expression","1+1");
        properties.setProperty("type","int");
        properties.setProperty("source_dict","int");
        properties.setProperty("dest_dict","1111");
        jsonParserUnderTest.xpath_nodeAttr.put("A",properties);
        // Run the test
        assertThatThrownBy(() ->jsonParserUnderTest.getSDO(values, context, true)).isInstanceOf(NullPointerException.class);

        // Verify the results
    }

//    @Test
//    public void testGetSDO_ThrowsParserException() {
//        // Setup
//        final Map values = Map.ofEntries();
//        final IBaseContext context = null;
//
//        // Run the test
//        assertThatThrownBy(() -> jsonParserUnderTest.getSDO(values, context, false)).isInstanceOf(
//                ParserException.class);
//    }

    @Test
    public void testOperate() throws Exception {
        // Setup
        final IServiceDataObject sdo = new SDO();
        final Map values = new HashMap();
        final IBaseContext context = null;
        Properties properties = new Properties();
        properties.setProperty("expression","1+1");
        properties.setProperty("type","int");
        properties.setProperty("source_dict","int");
        properties.setProperty("dest_dict","1111");
        properties.setProperty("cbrfield","1111");
        jsonParserUnderTest.xpath_nodeAttr.put("A",properties);
        // Run the test
        jsonParserUnderTest.operate(sdo, values, context);

        // Verify the results
    }

//    @Test
//    public void testOperate_ThrowsParserException() {
//        // Setup
//        final IServiceDataObject sdo = null;
//        final Map values = Map.ofEntries();
//        final IBaseContext context = null;
//
//        // Run the test
//        assertThatThrownBy(() -> jsonParserUnderTest.operate(sdo, values, context)).isInstanceOf(ParserException.class);
//    }

    @Test
    public void testCheckJson() throws Exception {
        // Setup
        // Run the test

        String arr = "{\n" + "        name\": \"Anna Doe\",\n" + "        \"age\": 5,\n" + "        \"isStudenta\": \"true\"\n" + "\t\n" + "    }";
        Field scanner = JSONParser.class.getDeclaredField("scanner");
        scanner.setAccessible(true);
        JSONScanner jsonScanner = new JSONScanner(arr.getBytes());
        scanner.set(jsonParserUnderTest, jsonScanner);
        assertThatThrownBy(() -> jsonParserUnderTest.checkJson()).isInstanceOf(ParserException.class);
        // Verify the results
    }


    @Test
    public void testMain() throws Exception {
        // Setup
        // Run the test

        File file = new File("/Users/zhoukan/Work/log/json.txt");
        if (file.exists()){
            file.delete();
        }
        FileUtil.write(content,"/Users/zhoukan/Work/log/","json.txt");
        FileUtil.renameFile("/Users/zhoukan/Work/log/","json.txtnull","json.txt");
        JSONParser.main(new String[]{"args"});

        // Verify the results
    }

    @Test
    public void testMain_ThrowsParserException() {
        // Setup
        // Run the test
        File file = new File("/Users/zhoukan/Work/log/json.txt");
        if (file.exists()){
            file.delete();
        }
        FileUtil.write("content","/Users/zhoukan/Work/log/","json.txt");
        FileUtil.renameFile("/Users/zhoukan/Work/log/","json.txtnull","json.txt");
        assertThatThrownBy(() -> JSONParser.main(new String[]{"args"})).isInstanceOf(ParserException.class);
    }
    @Test
    public void testGetValue() throws Exception {
        // Setup
        // Run the test
//        Method method = JSONParser.class.getDeclaredMethod("getValue", String.class, String.class);
//        method.setAccessible(true);
//        Object metadataid = method.invoke(jsonParserUnderTest, "message", "455");

        Object metadataid = invokeMethod(jsonParserUnderTest, "getValue","message", "666");
        System.out.println(metadataid);

    }
    @Test
    public void testProcessData() {
        // Setup
        // Run the test
        Properties properties = new Properties();
        properties.put(IMetaNodeAttr.FORMAT,"yyyyMMdd");
        invokeMethod(jsonParserUnderTest, "processData","", "b",properties);
        invokeMethod(jsonParserUnderTest, "processData","aaa", "b",properties);
        Object object = invokeMethod(jsonParserUnderTest, "processData","false", "b",properties);
        System.out.println(object);
        invokeMethod(jsonParserUnderTest, "processData","", "date",properties);
        object = invokeMethod(jsonParserUnderTest, "processData","20250604", "date",properties);
        System.out.println(object);
        invokeMethod(jsonParserUnderTest, "processData","", "double",properties);
        invokeMethod(jsonParserUnderTest, "processData","aaa", "double",properties);
        object = invokeMethod(jsonParserUnderTest, "processData","20250.604", "double",properties);
        System.out.println(object);
        invokeMethod(jsonParserUnderTest, "processData","", "float",properties);
        invokeMethod(jsonParserUnderTest, "processData","aaa", "float",properties);
        object = invokeMethod(jsonParserUnderTest, "processData","12.23", "Float",properties);
        System.out.println(object);
        invokeMethod(jsonParserUnderTest, "processData","", "integer",properties);
        invokeMethod(jsonParserUnderTest, "processData","aaa", "integer",properties);
        object = invokeMethod(jsonParserUnderTest, "processData","10", "iteger",properties);
        System.out.println(object);
        invokeMethod(jsonParserUnderTest, "processData","", "short",properties);
        invokeMethod(jsonParserUnderTest, "processData","aaa", "short",properties);
        object = invokeMethod(jsonParserUnderTest, "processData","2", "short",properties);
        System.out.println(object);
        object = invokeMethod(jsonParserUnderTest, "processData","aasadas2", "A",properties);
        System.out.println(object);

    }
    @Test
    public void testGetValueTypeClass() throws Exception {
        // Setup
        // Run the test
        Properties properties = new Properties();
        properties.setProperty("metadataid","message");
        properties.setProperty("type","Double");
        jsonParserUnderTest.xpath_nodeAttr.put("A",properties);
        properties = new Properties();
        properties.setProperty("metadataid","message");
        properties.setProperty("type","Float");
        jsonParserUnderTest.xpath_nodeAttr.put("B",properties);
        properties = new Properties();
        properties.setProperty("metadataid","message");
        properties.setProperty("type","Integer");
        jsonParserUnderTest.xpath_nodeAttr.put("C",properties);
        properties = new Properties();
        properties.setProperty("metadataid","message");
        properties.setProperty("type","aaaa");
        jsonParserUnderTest.xpath_nodeAttr.put("D",properties);
        Object object = invokeMethod(jsonParserUnderTest, "getValueTypeClass", "A");
        System.out.println(object);
        object = invokeMethod(jsonParserUnderTest, "getValueTypeClass", "B");
        System.out.println(object);
        object = invokeMethod(jsonParserUnderTest, "getValueTypeClass", "C");
        System.out.println(object);
        properties.remove("type");
        object = invokeMethod(jsonParserUnderTest, "getValueTypeClass", "D");
        System.out.println(object);

    }
    @Test
    public void testSetCBRField() throws Exception {
        // Setup
        // Run the test
        SDO sdo = new SDO();
        Map<String, String> map = new HashMap<>();
        map.put("C","A");
        Properties properties = new Properties();
        properties.put("cbrfield","C");
        properties.put("cbrmode","A:a;B:b");
        Method method = JSONParser.class.getDeclaredMethod("setCBRField", IServiceDataObject.class,Map.class,String.class,Properties.class, IBaseContext.class);
        method.setAccessible(true);
        Object object = method.invoke(jsonParserUnderTest,  sdo, map, "A", properties, new PoolableBaseContext(null));


    }
    @Test
    public void testParserArray() throws Exception {
        String arr = "[\n" + "    {\n" + "        \"name\": \"Anna Doe\",\n" + "        \"age\": 5,\n" + "        \"isStudenta\": \"true\"\n" + "    },\n" + "    {\n" + "        \"name\": \"John Doe\",\n" + "        \"age\": 30,\n" + "        \"isStudenta\": \"false\"\n" + "    }\n" + "]";
        Field scanner = JSONParser.class.getDeclaredField("scanner");
        scanner.setAccessible(true);
        JSONScanner jsonScanner = new JSONScanner(arr.getBytes());
        jsonScanner.reset();
        scanner.set(jsonParserUnderTest, jsonScanner);
        invokeMethod(jsonParserUnderTest, "parserArray", "root");
    }

}
