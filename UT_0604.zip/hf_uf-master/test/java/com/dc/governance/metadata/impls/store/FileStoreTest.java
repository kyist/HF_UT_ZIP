package com.dc.governance.metadata.impls.store;

import com.dc.esb.container.launcher.precompiler.PackageBean;
import com.dc.governance.metadata.interfaces.store.IDataStore;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.lang.reflect.Constructor;

import java.lang.reflect.Method;
import org.junit.runner.RunWith;
import java.io.File;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import java.lang.reflect.Field;


@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class FileStoreTest {

    private FileStore fileStore;
    private Method readFileMethod;
    private Method readPrivateFileMethod;
    private Method lookupFileMethod;

    @Before
    public void setUp() throws Exception {

        // 创建 FileStore 实例（构造函数是私有的）
        Constructor<FileStore> constructor = FileStore.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        fileStore = constructor.newInstance();

        // 获取私有方法 'readFile'
        readFileMethod = FileStore.class.getDeclaredMethod("readFile", File.class);
        readFileMethod.setAccessible(true);
        // 获取私有方法
        lookupFileMethod = FileStore.class.getDeclaredMethod("lookupFile", File.class, String.class);
        lookupFileMethod.setAccessible(true);

        readPrivateFileMethod = FileStore.class.getDeclaredMethod("_readFile", String.class, String.class);
        readPrivateFileMethod.setAccessible(true);

        readFileMethod = FileStore.class.getDeclaredMethod("readFile", File.class);
        readFileMethod.setAccessible(true);
    }

    // ---------------------- 测试 readFile 方法 ----------------------

    @Test
    public void testReadFile_ValidFile() throws Exception {
        // 创建临时文件
        File tempFile = createTempFile("test content");

        byte[] result = (byte[]) readFileMethod.invoke(fileStore, tempFile);

        Assert.assertNotNull(result);
        Assert.assertEquals("test content", new String(result));

        // 清理
        tempFile.delete();
    }

    @Test
    public void testReadFile_NullFile() throws Exception {
        byte[] result = (byte[]) readFileMethod.invoke(fileStore, (Object) null);

        Assert.assertNull(result);
    }

    @Test
    public void testReadFile_EmptyFile() throws Exception {
        // 创建空文件
        File tempFile = createTempFile("");

        byte[] result = (byte[]) readFileMethod.invoke(fileStore, tempFile);

        Assert.assertNotNull(result);
        Assert.assertEquals(0, result.length);

        // 清理
        tempFile.delete();
    }

    // ---------------------- 测试 _readFile 方法 ----------------------

    @Test
    public void testReadPrivateFile_ValidFile() throws Exception {
        // 创建临时目录和文件
        File rootDir = createTempDirectory();
        File testFile = new File(rootDir, "test.txt");
        writeContentToFile(testFile, "test content");

        byte[] result = (byte[]) readPrivateFileMethod.invoke(fileStore, rootDir.getAbsolutePath(), "test.txt");

        Assert.assertNotNull(result);
        Assert.assertEquals("test content", new String(result));

        // 清理
        deleteDirectory(rootDir);
    }

    @Test
    public void testReadPrivateFile_FileNotFound() throws Exception {
        // 创建临时目录
        File rootDir = createTempDirectory();

        byte[] result = (byte[]) readPrivateFileMethod.invoke(fileStore, rootDir.getAbsolutePath(), "nonexistent.txt");

        Assert.assertNull(result);

        // 清理
        deleteDirectory(rootDir);
    }

    @Test
    public void testReadPrivateFile_InvalidRootPath() throws Exception {
        byte[] result = (byte[]) readPrivateFileMethod.invoke(fileStore, "", "test.txt");

        Assert.assertNull(result);
    }

    // ---------------------- 测试 lookupFile 方法 ----------------------

    @Test
    public void testLookupFile_FileFound() throws Exception {
        // 创建临时目录结构
        File rootDir = createTempDirectory();
        File subDir = new File(rootDir, "subdir");
        subDir.mkdirs();

        File testFile = new File(subDir, "test.txt");
        writeContentToFile(testFile, "test content");

        File result = (File) lookupFileMethod.invoke(fileStore, rootDir, "test.txt");

        Assert.assertNotNull(result);
        Assert.assertEquals(testFile.getAbsolutePath(), result.getAbsolutePath());

        // 清理
        deleteDirectory(rootDir);
    }

    @Test
    public void testLookupFile_FileNotFound() throws Exception {
        // 创建临时目录
        File rootDir = createTempDirectory();

        File result = (File) lookupFileMethod.invoke(fileStore, rootDir, "nonexistent.txt");

        Assert.assertNull(result);

        // 清理
        deleteDirectory(rootDir);
    }

    @Test
    public void testLookupFile_EmptyDirectory() throws Exception {
        // 创建空目录
        File emptyDir = createTempDirectory();

        File result = (File) lookupFileMethod.invoke(fileStore, emptyDir, "test.txt");

        Assert.assertNull(result);

        // 清理
        deleteDirectory(emptyDir);
    }

    // ---------------------- 测试 getChannelMetaStruct 方法 ----------------------

    @Test
    public void testGetChannelMetaStruct_ValidConsumer() throws Exception {
        // 模拟 PackageBean
        PackageBean packageBean;
        Constructor c = PackageBean.class.getDeclaredConstructor();
        c.setAccessible(true);
        packageBean = (PackageBean) c.newInstance();
        packageBean.setAccessType(1);  // 消费者

        // 创建临时文件
        File consumerDir = new File(FileStore.CONSUMER_ROOT_PATH);
        if (!consumerDir.exists()) {
            consumerDir.mkdirs();
        }

        String fileName = MetaStructFileNameGetter.getChannelMetaStructFileName(packageBean);
        File testFile = new File(consumerDir, fileName);
        writeContentToFile(testFile, "channel meta struct content");

        byte[] result = fileStore.getChannelMetaStruct(packageBean);

        Assert.assertNotNull(result);
        Assert.assertEquals("channel meta struct content", new String(result));

        // 清理
        testFile.delete();
    }

    @Test
    public void testGetChannelMetaStruct_ValidProvider() throws Exception {
        // 模拟 PackageBean
        PackageBean packageBean;
        Constructor c = PackageBean.class.getDeclaredConstructor();
        c.setAccessible(true);
        packageBean = (PackageBean) c.newInstance();
        packageBean.setAccessType(2);  // 提供者

        // 创建临时文件
        File providerDir = new File(FileStore.PROVIDER_ROOT_PATH);
        if (!providerDir.exists()) {
            providerDir.mkdirs();
        }

        String fileName = MetaStructFileNameGetter.getChannelMetaStructFileName(packageBean);
        File testFile = new File(providerDir, fileName);
        writeContentToFile(testFile, "channel meta struct content");

        byte[] result = fileStore.getChannelMetaStruct(packageBean);

        Assert.assertNotNull(result);
        Assert.assertEquals("channel meta struct content", new String(result));

        // 清理
        testFile.delete();
    }

    @Test
    public void testGetChannelMetaStruct_InvalidAccessType() throws Exception {
        // 模拟 PackageBean
        PackageBean packageBean;
        Constructor c = PackageBean.class.getDeclaredConstructor();
        c.setAccessible(true);
        packageBean = (PackageBean) c.newInstance();
        packageBean.setAccessType(3);  // 无效访问类型

        byte[] result = fileStore.getChannelMetaStruct(packageBean);

        Assert.assertNull(result);
    }

    // ---------------------- 测试其他公共方法 ----------------------

    @Test
    public void testGetMetaDataContent() throws Exception {
        // 创建临时文件
        File metadataDir = new File(FileStore.METADATA_ROOT_PATH);
        if (!metadataDir.exists()) {
            metadataDir.mkdirs();
        }

        String fileName = MetaStructFileNameGetter.getMetaDataFileName();
        File testFile = new File(metadataDir, fileName);
        writeContentToFile(testFile, "metadata content");

        byte[] result = fileStore.getMetaDataContent();

        Assert.assertNotNull(result);
        Assert.assertEquals("metadata content", new String(result));

        // 清理
        testFile.delete();
    }

    @Test
    public void testGetServiceMetaStruct() throws Exception {
        // 模拟 PackageBean
        PackageBean packageBean;
        Constructor c = PackageBean.class.getDeclaredConstructor();
        c.setAccessible(true);
        packageBean = (PackageBean) c.newInstance();

        // 创建临时文件
        File serviceDir = new File(FileStore.SERVICE_ROOT_PATH);
        if (!serviceDir.exists()) {
            serviceDir.mkdirs();
        }

        String fileName = MetaStructFileNameGetter.getServiceMetaStructFileName(packageBean);
        File testFile = new File(serviceDir, fileName);
        writeContentToFile(testFile, "service meta struct content");

        byte[] result = fileStore.getServiceMetaStruct(packageBean);

        Assert.assertNotNull(result);
        Assert.assertEquals("service meta struct content", new String(result));

        // 清理
        testFile.delete();
    }

    // ---------------------- 辅助方法 ----------------------

    private File createTempDirectory() throws IOException {
        File tempDir = File.createTempFile("testDir", Long.toString(System.nanoTime()));
        tempDir.delete();
        tempDir.mkdirs();
        return tempDir;
    }

    private File createTempFile(String content) throws IOException {
        File tempFile = File.createTempFile("testFile", ".txt");
        tempFile.deleteOnExit();
        writeContentToFile(tempFile, content);
        return tempFile;
    }

    private void writeContentToFile(File file, String content) throws IOException {
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(content);
        }
    }

    private boolean deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        deleteDirectory(file);
                    } else {
                        file.delete();
                    }
                }
            }
        }
        return directory.delete();
    }

    @Test
    public void testResucFindFile_FileFound() {
        // 创建 mock 对象
        File rootDir = mock(File.class);
        File subDir = mock(File.class);
        File targetFile = mock(File.class);

        // 设置行为和返回值
        //when(rootDir.isDirectory()).thenReturn(true);
        when(subDir.isDirectory()).thenReturn(true);
        when(targetFile.isDirectory()).thenReturn(false);
        when(targetFile.getName()).thenReturn("target.txt");

        // 构建目录结构：rootDir -> subDir -> targetFile
        when(rootDir.listFiles()).thenReturn(new File[]{subDir});
        when(subDir.listFiles()).thenReturn(new File[]{targetFile});

        // 执行方法
        File result = FileStore.resucFindFile(rootDir, "target.txt");

        // 验证结果
        assertNotNull(result);
        assertEquals(targetFile, result);
    }

    @Test
    public void testResucFindFile_FileNotFound() {
        // 创建 mock 对象
        File rootDir = mock(File.class);

        // 设置行为
//        when(rootDir.isDirectory()).thenReturn(true);
        when(rootDir.listFiles()).thenReturn(null); // 没有子文件

        // 执行方法
        File result = FileStore.resucFindFile(rootDir, "nonexistent.txt");

        // 验证结果
        assertNull(result);
    }


    /**
     * 在每次测试前重置单例状态
     */
    private void resetSingleton() throws Exception {
        Field instanceField = FileStore.class.getDeclaredField("dataStore");
        instanceField.setAccessible(true);
        instanceField.set(null, null);
    }

    @Test
    public void testGetInstance_FirstCall_ShouldCreateNewInstance() throws Exception {
        // 重置单例状态
        resetSingleton();

        // 调用 getInstance
        IDataStore instance = FileStore.getInstance();

        // 验证非空且为 FileStore 实例
        assertNotNull(instance);
        assertTrue(instance instanceof FileStore);
    }

    @Test
    public void testGetInstance_MultipleCalls_ShouldReturnSameInstance() throws Exception {
        // 重置单例状态
        resetSingleton();

        // 第一次调用
        IDataStore instance1 = FileStore.getInstance();
        // 第二次调用
        IDataStore instance2 = FileStore.getInstance();

        // 验证两次获取的是同一个实例
        assertNotNull(instance1);
        assertNotNull(instance2);
        assertSame(instance1, instance2);
    }

    @Test
    public void testGetInstance_Multithreaded_ShouldReturnSameInstance() throws Exception {
        // 重置单例状态
        resetSingleton();

        final int THREAD_COUNT = 10;
        final IDataStore[] instances = new IDataStore[THREAD_COUNT];
        Thread[] threads = new Thread[THREAD_COUNT];

        // 创建并启动多个线程同时调用 getInstance
        for (int i = 0; i < THREAD_COUNT; i++) {
            final int index = i;
            threads[i] = new Thread(() -> {
                instances[index] = FileStore.getInstance();
            });
            threads[i].start();
        }

        // 等待所有线程完成
        for (Thread thread : threads) {
            thread.join();
        }

        // 验证所有线程获取的是同一个实例
        for (int i = 1; i < THREAD_COUNT; i++) {
            assertNotNull(instances[i]);
            assertSame(instances[0], instances[i]);
        }
    }

    @Test
    public void testGetServiceSystemMetaStruct_AccessType1() throws Exception {
        // 模拟 PackageBean
        PackageBean packageBean = mock(PackageBean.class);
        when(packageBean.getAccessType()).thenReturn(1);

        // 设置静态路径（通过反射修改）
       // setFinalStatic(FileStore.class, "CONSUMER_ROOT_PATH", "/mock/consumer");

        // 替换 MetaStructFileNameGetter 的行为（模拟返回固定值）
        String expectedFileName = "service-system-meta.txt";

        // 构造预期文件路径
        String constructedPath = FileStore.CONSUMER_ROOT_PATH + File.separator + expectedFileName;
        File expectedFile = new File(constructedPath);

        // 调用被测方法
        byte[] result = (byte[]) FileStore.class
                .getMethod("getServiceSystemMetaStruct", PackageBean.class)
                .invoke(fileStore, packageBean);

        // 验证结果
        //assertNotNull(result);
        //assertEquals("mock content for consumer", new String(result));
    }

    @Test
    public void testGetServiceSystemMetaStruct_AccessType2() throws Exception {
        // 模拟 PackageBean
        PackageBean packageBean = mock(PackageBean.class);
        when(packageBean.getAccessType()).thenReturn(2);

        // 设置静态路径（通过反射修改）
        //setFinalStatic(FileStore.class, "PROVIDER_ROOT_PATH", "/mock/provider");

        // 替换 MetaStructFileNameGetter 的行为（模拟返回固定值）
        String expectedFileName = "service-system-meta.txt";

        // 构造预期文件路径
        String constructedPath = FileStore.PROVIDER_ROOT_PATH + File.separator + expectedFileName;
        File expectedFile = new File(constructedPath);


        // 调用被测方法
        byte[] result = (byte[]) FileStore.class
                .getMethod("getServiceSystemMetaStruct", PackageBean.class)
                .invoke(fileStore, packageBean);

        // 验证结果
        //assertNotNull(result);
        //assertEquals("mock content for provider", new String(result));
    }

    @Test
    public void testGetServiceSystemMetaStruct_InvalidAccessType() throws Exception {
        // 模拟 PackageBean
        PackageBean packageBean = mock(PackageBean.class);
        when(packageBean.getAccessType()).thenReturn(3); // 无效类型

        // 调用被测方法
        byte[] result = fileStore.getServiceSystemMetaStruct(packageBean);

        // 验证返回 null
        assertNull(result);
    }

    /**
     * 修改类中的 private static final 字段的值（兼容 JDK 9+）
     */
    private void setFinalStatic(Class<?> clazz, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);

        try {
            // 尝试获取 modifiers 字段（JDK 8 及以下需要）
            java.lang.reflect.Field modifiersField = java.lang.reflect.Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(field, field.getModifiers() & ~java.lang.reflect.Modifier.FINAL);
        } catch (NoSuchFieldException e) {
            // JDK 9+ 中没有 modifiers 字段，忽略即可
        }

        //field.set(null, value);
    }

}
