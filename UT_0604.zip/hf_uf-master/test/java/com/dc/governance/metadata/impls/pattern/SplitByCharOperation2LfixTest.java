package com.dc.governance.metadata.impls.pattern;

import com.dc.governance.metadata.interfaces.exception.OperationRunntimeException;
import com.dc.governance.metadata.interfaces.parser.IMetaNodeAttr;
import com.dc.governance.metadata.interfaces.pattern.OperationFactor;
import org.apache.commons.io.input.BrokenInputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SplitByCharOperation2LfixTest {

    private SplitByCharOperation2Lfix splitByCharOperation2LfixUnderTest;

    @BeforeEach
    void setUp() {
        splitByCharOperation2LfixUnderTest = new SplitByCharOperation2Lfix();
    }

    @Test
    void testOperate() throws Exception {
        SplitByCharOperation2Lfix operation = new SplitByCharOperation2Lfix();
        OperationFactor parentFactor = mock(OperationFactor.class);
        OperationFactor parentFactor2 = mock(OperationFactor.class);
        when(parentFactor.getValue()).thenReturn("1||2||3".getBytes());
        when(parentFactor.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn("|");
        List<OperationFactor> childrenFactor = new ArrayList<>();
        OperationFactor operationFactor = new OperationFactor("test",new Properties());
        OperationFactor operationFactor2 = new OperationFactor("test2",new Properties());
        OperationFactor operationFactor3 = new OperationFactor("test3",new Properties());
        operationFactor.addChild(operationFactor2);
        operationFactor2.addChild(operationFactor);
        operationFactor3.addChild(operationFactor2);
        childrenFactor.add(operationFactor);
        childrenFactor.add(operationFactor2);
        childrenFactor.add(operationFactor3);
        try {
            Hashtable<String, Object> result = operation.operate(parentFactor, childrenFactor);
        }catch (OperationRunntimeException e) {

        }



    }
@Test
void testIsSplitStr() throws Exception {
    SplitByCharOperation2Lfix splitByCharOperation = new SplitByCharOperation2Lfix();
    //反射获取方法
    Method dealOperation =SplitByCharOperation2Lfix.class.getDeclaredMethod("isSplitStr",InputStream.class,int.class,byte[].class);
    //私有化方法设置为可访问
    dealOperation.setAccessible(true);
    byte[] a = "123455666".getBytes();
    InputStream in1 = new ByteArrayInputStream(a);
    dealOperation.invoke(splitByCharOperation,in1,2,new byte[]{1,2,4});
}

    @Test
    void testReadToChar1() throws Exception {
        // Setup
        final InputStream in = new ByteArrayInputStream("cont88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888cont8888888888888888888888888888888888888888888888888888888888888888888888888888888888cont88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888cont8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888cont888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888cont88".getBytes());

        // Run the test
        final byte[] result = splitByCharOperation2LfixUnderTest.readToChar(in, (byte) 0b0);


        //

//        final InputStream in2 = new ByteArrayInputStream("content".getBytes());
//
//        final byte[] result2 = splitByCharOperation2LfixUnderTest.readToChar(in2, (byte) 0b0);
    }

    @Test
    void testReadToChar1_EmptyIn() throws Exception {
        // Setup
        final InputStream in = InputStream.nullInputStream();

        // Run the test
        final byte[] result = splitByCharOperation2LfixUnderTest.readToChar(in, (byte) 0b0);

    }

    @Test
    void testReadToChar1_BrokenIn() {
        // Setup
        final InputStream in = new BrokenInputStream();

        // Run the test
        assertThatThrownBy(() -> splitByCharOperation2LfixUnderTest.readToChar(in, (byte) 0b0))
                .isInstanceOf(IOException.class);
    }

    @Test
    void testReadToChar2() throws Exception {
        // Setup
        final InputStream in = new ByteArrayInputStream("content".getBytes());

        // Run the test
        final byte[] result = splitByCharOperation2LfixUnderTest.readToChar(in, "content".getBytes());

    }


    @Test
    void testReadToChar2_EmptyIn() throws Exception {
        // Setup
        final InputStream in = InputStream.nullInputStream();

        // Run the test
        final byte[] result = splitByCharOperation2LfixUnderTest.readToChar(in, "content".getBytes());

        // Verify the results
    }

    @Test
    void testReadToChar2_BrokenIn() {
        // Setup
        final InputStream in = new BrokenInputStream();

        // Run the test
        assertThatThrownBy(() -> splitByCharOperation2LfixUnderTest.readToChar(in, "content".getBytes()))
                .isInstanceOf(IOException.class);
    }

    @Test
    void testMain() throws Exception {
        // Setup
        // Run the test
        try {
            SplitByCharOperation2Lfix.main(new String[]{"args"});
        } catch (Exception e) {
        }
        // Verify the results
    }

    @Test
    void testMain_ThrowsException() {
        // Setup
        // Run the test
        assertThatThrownBy(() -> SplitByCharOperation2Lfix.main(new String[]{"args"})).isInstanceOf(Exception.class);
    }
}
