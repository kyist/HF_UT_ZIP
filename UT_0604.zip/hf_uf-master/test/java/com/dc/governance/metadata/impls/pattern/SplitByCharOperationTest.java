package com.dc.governance.metadata.impls.pattern;

import com.dc.governance.metadata.interfaces.parser.IMetaNodeAttr;
import com.dc.governance.metadata.interfaces.pattern.OperationFactor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@RunWith(PowerMockRunner.class)
@PrepareForTest()
public class SplitByCharOperationTest {
    private SplitByCharOperation splitByCharOperation;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void operate() throws Exception {
        SplitByCharOperation operation = new SplitByCharOperation();
        OperationFactor parentFactor = mock(OperationFactor.class);
        when(parentFactor.getValue()).thenReturn("A|B|C".getBytes());
        when(parentFactor.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn("|");
        List<OperationFactor> childrenFactor = new ArrayList<>();
        OperationFactor childFactor =  mock(OperationFactor.class);
        Hashtable<String, Object> result = operation.operate(parentFactor, childrenFactor);
    }
    @Test
    public void dealOperation() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        //反射获取方法
        Method dealOperation =SplitByCharOperation.class.getDeclaredMethod("dealOperation",List.class,Hashtable.class,byte[].class,InputStream.class);
        //私有化方法设置为可访问
        dealOperation.setAccessible(true);

//        SplitByCharOperation operation = new SplitByCharOperation();
        Hashtable<String, Object> values1 = new Hashtable<>();
        InputStream in1 = new ByteArrayInputStream(new byte[0]);
        List<OperationFactor> childrenFactor =new ArrayList<>();
        OperationFactor operationFactor = new OperationFactor("test",new Properties());
        childrenFactor.add(operationFactor);
        dealOperation.invoke(splitByCharOperation,childrenFactor, values1, new byte[]{'|'}, in1);
        assertTrue(values1.isEmpty());



        Hashtable<String, Object> values2 = new Hashtable<>();
        InputStream in2 = new ByteArrayInputStream(new byte[0]);
        dealOperation.invoke(splitByCharOperation,new ArrayList<>(), values2, new byte[]{'|'}, in2);
//        operation.dealOperation(new ArrayList<>(), values2, new byte[]{'|'}, in2);
        assertTrue(values2.isEmpty());



        OperationFactor childFactor3 = mock(OperationFactor.class);
        when(childFactor3.getRestriction("multSplit")).thenReturn("true");
        List<OperationFactor> childrenFactor3 = new ArrayList<>();
        childrenFactor3.add(childFactor3);
        Hashtable<String, Object> values3 = new Hashtable<>();
        InputStream in3 = new ByteArrayInputStream(new byte[0]);
        dealOperation.invoke(splitByCharOperation,childrenFactor3, values3, new byte[]{'|'}, in3);
//        operation.dealOperation(childrenFactor3, values3, new byte[]{'|'}, in3);



        OperationFactor childFactor4 = mock(OperationFactor.class);
        when(childFactor4.getRestriction(IMetaNodeAttr.TYPE)).thenReturn("array");
        List<OperationFactor> childrenFactor4 = new ArrayList<>();
        childrenFactor4.add(childFactor4);
        Hashtable<String, Object> values4 = new Hashtable<>();
        InputStream in4 = new ByteArrayInputStream(new byte[0]);
        dealOperation.invoke(splitByCharOperation,childrenFactor4, values4, new byte[]{'|'}, in4);


////        SplitByCharOperation operation = new SplitByCharOperation();
//        OperationFactor childFactor5 = mock(OperationFactor.class);
//        when(childFactor5.getRestriction(IMetaNodeAttr.SWITCH_FIELD)).thenReturn("switchField");
//        when(childFactor5.getColumns()).thenReturn(new LinkedList<>());
//        List<OperationFactor> childrenFactor5 = new ArrayList<>();
//        childrenFactor5.add(childFactor5);
//        Hashtable<String, Object> values5 = new Hashtable<>();
//        values5.put("switchField", "value");
//        InputStream in5 = new ByteArrayInputStream(new byte[0]);
//        dealOperation.invoke(splitByCharOperation,childrenFactor5, values5, new byte[]{'|'}, in5);
////        operation.dealOperation(childrenFactor5, values5, new byte[]{'|'}, in5);


        OperationFactor childFactor6 = mock(OperationFactor.class);
        when(childFactor6.getRestriction(IMetaNodeAttr.TYPE)).thenReturn(null);
        when(childFactor6.getRestriction(IMetaNodeAttr.SWITCH_FIELD)).thenReturn(null);
        List<OperationFactor> childrenFactor6 = new ArrayList<>();
        childrenFactor6.add(childFactor6);
        Hashtable<String, Object> values6 = new Hashtable<>();
        InputStream in6 = new ByteArrayInputStream(new byte[0]);
        dealOperation.invoke(splitByCharOperation,childrenFactor6, values6, new byte[]{'|'}, in6);


        Hashtable<String, Object> values7 = new Hashtable<>();
        values7.put("123","1");
        InputStream in7 = new ByteArrayInputStream(new byte[0]);
        List<OperationFactor> childrenFactor7 =new ArrayList<>();
        Properties properties = new Properties();
        properties.setProperty(IMetaNodeAttr.SWITCH_FIELD,"123");
        properties.setProperty(IMetaNodeAttr.SWITCHMODE,"1:2;3:4");
        OperationFactor operationFactor7 = new OperationFactor("2",properties);
        operationFactor7.addChild(operationFactor7);
        childrenFactor7.add(operationFactor7);
        try {
            dealOperation.invoke(splitByCharOperation, childrenFactor7, values7, new byte[]{'|'}, in7);
            assertTrue(values7.isEmpty());
        }catch (Exception e){
            e.printStackTrace();
        }

//
    }

    @Test
    public void testMain() throws Exception {
        // Setup
        // Run the test
        try {
            SplitByCharOperation.main(new String[]{"args"});
        }catch (Exception e){

        }
        // Verify the results
    }

    @Test
    public void parseSwitchModes() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        //反射获取方法
        Method parseSwitchModes =SplitByCharOperation.class.getDeclaredMethod("parseSwitchModes",OperationFactor.class);
        //私有化方法设置为可访问
        parseSwitchModes.setAccessible(true);

        SplitByCharOperation operation = new SplitByCharOperation();
        OperationFactor child1 = mock(OperationFactor.class);
        when(child1.getRestriction(IMetaNodeAttr.SWITCHMODE)).thenReturn("value1:node1;value2:node2");
        Map<String, String> result1 = (Map<String, String>) parseSwitchModes.invoke(splitByCharOperation,child1);
        assertEquals(2, result1.size());
        assertEquals("node1", result1.get("value1"));
        assertEquals("node2", result1.get("value2"));

        OperationFactor child2 = mock(OperationFactor.class);
        when(child2.getRestriction(IMetaNodeAttr.SWITCHMODE)).thenReturn("A:1:2;B:1:2;C:1:2");
        Map<String, String> result2 = (Map<String, String>) parseSwitchModes.invoke(splitByCharOperation,child2);
//        assertTrue(result2.isEmpty());
    }

    @Test
    public void reSplit1() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method reSplitMethod = SplitByCharOperation.class.getDeclaredMethod("reSplit", InputStream.class, byte[].class, LinkedList.class, Hashtable.class, byte[].class);
        reSplitMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream("A|B|C|D".getBytes());
        byte[] multSplit = "|".getBytes();
        byte[] preSplit = "|".getBytes();
        LinkedList<OperationFactor> columns = new LinkedList<>();
        OperationFactor column1 = mock(OperationFactor.class);
        when(column1.getFactorName()).thenReturn("col1");
        when(column1.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(null);
        columns.add(column1);
        OperationFactor column2 = mock(OperationFactor.class);
        when(column2.getFactorName()).thenReturn("col2");
        when(column2.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(null);
        columns.add(column2);
        Hashtable<String, Object> values = new Hashtable<>();
        reSplitMethod.invoke(splitByCharOperation, in, multSplit, columns, values, preSplit);
//        assertEquals("A", values.get("col1"));
//        assertEquals("B", values.get("col2"));
    }
    @Test
    public void reSplit2() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method reSplitMethod = SplitByCharOperation.class.getDeclaredMethod("reSplit", InputStream.class, byte[].class, LinkedList.class, Hashtable.class, byte[].class);
        reSplitMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream("A,B,C,D".getBytes());
        byte[] multSplit = ",".getBytes();
        byte[] preSplit = "|".getBytes();
        LinkedList<OperationFactor> columns = new LinkedList<>();
        OperationFactor column1 = mock(OperationFactor.class);
        when(column1.getFactorName()).thenReturn("col1");
        when(column1.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(",");
        columns.add(column1);
        OperationFactor column2 = mock(OperationFactor.class);
        when(column2.getFactorName()).thenReturn("col2");
        when(column2.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(",");
        columns.add(column2);
        Hashtable<String, Object> values = new Hashtable<>();
        reSplitMethod.invoke(splitByCharOperation, in, multSplit, columns, values, preSplit);
    }

    @Test
    public void reSplit3() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method reSplitMethod = SplitByCharOperation.class.getDeclaredMethod("reSplit", InputStream.class, byte[].class, LinkedList.class, Hashtable.class, byte[].class);
        reSplitMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream("".getBytes());
        byte[] multSplit = "|".getBytes();
        byte[] preSplit = "|".getBytes();
        LinkedList<OperationFactor> columns = new LinkedList<>();
        OperationFactor column1 = mock(OperationFactor.class);
        when(column1.getFactorName()).thenReturn("col1");
        when(column1.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(null);
        columns.add(column1);
        Hashtable<String, Object> values = new Hashtable<>();
        reSplitMethod.invoke(splitByCharOperation, in, multSplit, columns, values, preSplit);
        assertNull(values.get("col1"));
    }
    @Test
    public void dealArray1() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method dealArrayMethod = SplitByCharOperation.class.getDeclaredMethod("dealArray", Hashtable.class, byte[].class, InputStream.class, OperationFactor.class);
        dealArrayMethod.setAccessible(true);
        Hashtable<String, Object> values = new Hashtable<>();
        InputStream in = new ByteArrayInputStream("A|B|C|D".getBytes());
        byte[] split = "|".getBytes();
        OperationFactor child = mock(OperationFactor.class);
        when(child.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn("|");
        when(child.getRestriction("arraySize")).thenReturn("arraySize");
        when(child.getColumns()).thenReturn(new LinkedList<>());
        values.put("arraySize", "4");
        dealArrayMethod.invoke(splitByCharOperation, values, split, in, child);
    }
//    @Test
//    public void dealArray2() throws Exception {
//        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
//        Method dealArrayMethod = SplitByCharOperation.class.getDeclaredMethod("dealArray", Hashtable.class, byte[].class, InputStream.class, OperationFactor.class);
//        dealArrayMethod.setAccessible(true);
//
//        Hashtable<String, Object> values = new Hashtable<>();
//        InputStream in = new ByteArrayInputStream("A|B|C|D".getBytes());
//        byte[] split = "|".getBytes();
//        OperationFactor child = mock(OperationFactor.class);
//        when(child.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn("|");
//        when(child.getRestriction("arraySize")).thenReturn(null);
//        when(child.getColumns()).thenReturn(new LinkedList<>());
//        dealArrayMethod.invoke(splitByCharOperation, values, split, in, child);
//        assertNotNull(values);
//    }
//    @Test
//    public void dealArray3() throws Exception {
//        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
//        Method dealArrayMethod = SplitByCharOperation.class.getDeclaredMethod("dealArray", Hashtable.class, byte[].class, InputStream.class, OperationFactor.class);
//        dealArrayMethod.setAccessible(true);
//        Hashtable<String, Object> values = new Hashtable<>();
//        InputStream in = new ByteArrayInputStream(new byte[0]);
//        byte[] split = "|".getBytes();
//        OperationFactor child = mock(OperationFactor.class);
//        when(child.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn("|");
////        when(child.getRestriction("arraySize")).thenReturn(null);
//        when(child.getColumns()).thenReturn(new LinkedList<>());
//        dealArrayMethod.invoke(splitByCharOperation, values, split, in, child);
//        assertTrue(values.isEmpty());
//    }
    @Test
    public void readRow1() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method readRowMethod = SplitByCharOperation.class.getDeclaredMethod("_readRow", InputStream.class, byte[].class, LinkedList.class, HashMap.class, int.class);
        readRowMethod.setAccessible(true);

        InputStream in = new ByteArrayInputStream("A|B|C|D".getBytes());
        byte[] arraySplit = "|".getBytes();
        LinkedList<OperationFactor> columns = new LinkedList<>();
        OperationFactor column1 = mock(OperationFactor.class);
        when(column1.getFactorName()).thenReturn("col1");
        when(column1.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(null);
        columns.add(column1);
        OperationFactor column2 = mock(OperationFactor.class);
        when(column2.getFactorName()).thenReturn("col2");
        when(column2.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(null);
        columns.add(column2);
        HashMap<String, LinkedList> columnsValues = new HashMap<>();
        readRowMethod.invoke(splitByCharOperation, in, arraySplit, columns, columnsValues, 0);
    }

    @Test
    public void readRow2() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method readRowMethod = SplitByCharOperation.class.getDeclaredMethod("_readRow", InputStream.class, byte[].class, LinkedList.class, HashMap.class, int.class);
        readRowMethod.setAccessible(true);

        InputStream in = new ByteArrayInputStream("A,B,C,D".getBytes());
        byte[] arraySplit = "|".getBytes();
        LinkedList<OperationFactor> columns = new LinkedList<>();
        OperationFactor column1 = mock(OperationFactor.class);
        when(column1.getFactorName()).thenReturn("col1");
        when(column1.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(",");
        columns.add(column1);
        OperationFactor column2 = mock(OperationFactor.class);
        when(column2.getFactorName()).thenReturn("col2");
        when(column2.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(",");
        columns.add(column2);
        HashMap<String, LinkedList> columnsValues = new HashMap<>();
        readRowMethod.invoke(splitByCharOperation, in, arraySplit, columns, columnsValues, 0);
    }
    @Test
    public void readRow_withEmptyInput_shouldNotPopulateColumnsValues() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method readRowMethod = SplitByCharOperation.class.getDeclaredMethod("_readRow", InputStream.class, byte[].class, LinkedList.class, HashMap.class, int.class);
        readRowMethod.setAccessible(true);

        InputStream in = new ByteArrayInputStream("".getBytes());
        byte[] arraySplit = "|".getBytes();
        LinkedList<OperationFactor> columns = new LinkedList<>();
        OperationFactor column1 = mock(OperationFactor.class);
        when(column1.getFactorName()).thenReturn("col1");
        when(column1.getRestriction(IMetaNodeAttr.SPLIT_CHAR)).thenReturn(null);
        columns.add(column1);
        HashMap<String, LinkedList> columnsValues = new HashMap<>();
        readRowMethod.invoke(splitByCharOperation, in, arraySplit, columns, columnsValues, 0);
    }

    @Test
    public void readToChar() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method readToCharMethod = SplitByCharOperation.class.getDeclaredMethod("readToChar", InputStream.class, byte.class);
        readToCharMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream("A|B|C|D".getBytes());
        byte endChar = '|';
        byte[] result = (byte[]) readToCharMethod.invoke(splitByCharOperation, in, endChar);
        assertArrayEquals("A".getBytes(), result);
    }

    @Test
    public void readToChar2() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method readToCharMethod = SplitByCharOperation.class.getDeclaredMethod("readToChar", InputStream.class, byte.class);
        readToCharMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream(new byte[0]);
        byte endChar = '|';
        byte[] result = (byte[]) readToCharMethod.invoke(splitByCharOperation, in, endChar);
        assertNull(result);
    }
    @Test
    public void readToChar3() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method readToCharMethod = SplitByCharOperation.class.getDeclaredMethod("readToChar", InputStream.class, byte.class);
        readToCharMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream("ABCDE".getBytes());
        byte endChar = '|';
        byte[] result = (byte[]) readToCharMethod.invoke(splitByCharOperation, in, endChar);
    }
    @Test
    public void readToChar4() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method readToCharMethod = SplitByCharOperation.class.getDeclaredMethod("readToChar", InputStream.class, byte.class);
        readToCharMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream("A \n\t|B|C|D".getBytes());
        byte endChar = '|';
        byte[] result = (byte[]) readToCharMethod.invoke(splitByCharOperation, in, endChar);
   }
    @Test
    public void isSplitStr1() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method isSplitStrMethod = SplitByCharOperation.class.getDeclaredMethod("isSplitStr", InputStream.class, int.class, byte[].class);
        isSplitStrMethod.setAccessible(true);
        InputStream in = new ByteArrayInputStream("ABC|DEF".getBytes());
        byte[] endChars = "|".getBytes();
        boolean result = (boolean) isSplitStrMethod.invoke(splitByCharOperation, in, 3, endChars);
        assertTrue(result);
    }

    @Test
    public void isSplitStr2() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method isSplitStrMethod = SplitByCharOperation.class.getDeclaredMethod("isSplitStr", InputStream.class, int.class, byte[].class);
        isSplitStrMethod.setAccessible(true);

        InputStream in = new ByteArrayInputStream("ABCDEF".getBytes());
        byte[] endChars = "|".getBytes();
        boolean result = (boolean) isSplitStrMethod.invoke(splitByCharOperation, in, 3, endChars);
    }

    @Test
    public void isSplitStr3() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method isSplitStrMethod = SplitByCharOperation.class.getDeclaredMethod("isSplitStr", InputStream.class, int.class, byte[].class);
        isSplitStrMethod.setAccessible(true);

        InputStream in = new ByteArrayInputStream(new byte[0]);
        byte[] endChars = "|".getBytes();
        boolean result = (boolean) isSplitStrMethod.invoke(splitByCharOperation, in, 0, endChars);
    }

    @Test
    public void isSplitStr4() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method isSplitStrMethod = SplitByCharOperation.class.getDeclaredMethod("isSplitStr", InputStream.class, int.class, byte[].class);
        isSplitStrMethod.setAccessible(true);

        InputStream in = new ByteArrayInputStream("ABC||DEF".getBytes());
        byte[] endChars = "||".getBytes();
        boolean result = (boolean) isSplitStrMethod.invoke(splitByCharOperation, in, 3, endChars);
    }

    @Test
    public void isSplitStr_withMultiCharEndChars_shouldReturnFalse() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        Method isSplitStrMethod = SplitByCharOperation.class.getDeclaredMethod("isSplitStr", InputStream.class, int.class, byte[].class);
        isSplitStrMethod.setAccessible(true);

        InputStream in = new ByteArrayInputStream("ABC|DEF".getBytes());
        byte[] endChars = "||".getBytes();
        boolean result = (boolean) isSplitStrMethod.invoke(splitByCharOperation, in, 3, endChars);
    }

    @Test
    public void getValueTypeClass1() throws Exception {
        SplitByCharOperation splitByCharOperation = new SplitByCharOperation();
        //反射获取方法
        Method getValueTypeClass =SplitByCharOperation.class.getDeclaredMethod("getValueTypeClass",String.class);
        //私有化方法设置为可访问
        getValueTypeClass.setAccessible(true);

        getValueTypeClass.invoke(splitByCharOperation,"integer");
        getValueTypeClass.invoke(splitByCharOperation,"float");
        getValueTypeClass.invoke(splitByCharOperation,"double");
        getValueTypeClass.invoke(splitByCharOperation,"string");
        getValueTypeClass.invoke(splitByCharOperation,"XXXXXXXXXXXXXXXXXX");
        getValueTypeClass.invoke(splitByCharOperation,"");
        getValueTypeClass.invoke(splitByCharOperation,"unknown");
    }

}