package com.dcits.smartbip.utils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ClassHelperTest {

    private ClassLoader testClassLoader;

    @BeforeEach
    public void setUp() {
        testClassLoader = Thread.currentThread().getContextClassLoader();
    }

    @Test
    public void testForNameWithThreadContextClassLoader() throws ClassNotFoundException {
        Class<?> clazz = ClassHelper.forNameWithThreadContextClassLoader("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    public void testForNameWithCallerClassLoader() throws ClassNotFoundException {
        Class<?> clazz = ClassHelper.forNameWithCallerClassLoader("java.lang.String", ClassHelper.class);
        assertEquals(String.class, clazz);
    }

    @Test
    public void testGetCallerClassLoader() {
        ClassLoader cl = ClassHelper.getCallerClassLoader(ClassHelper.class);
        assertNotNull(cl);
    }

    @Test
    public void testGetClassLoader() {
        ClassLoader cl = ClassHelper.getClassLoader();
        assertNotNull(cl);
    }

    @Test
    public void testGetClassLoaderWithClass() {
        ClassLoader cl = ClassHelper.getClassLoader(ClassHelper.class);
        assertNotNull(cl);
    }

    @Test
    public void testForName() throws ClassNotFoundException {
        Class<?> clazz = ClassHelper.forName("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    public void testForNameWithClassLoader() throws ClassNotFoundException {
        Class<?> clazz = ClassHelper.forName("java.lang.String", testClassLoader);
        assertEquals(String.class, clazz);
    }

    @Test
    public void testForNameWithPrimitive() throws ClassNotFoundException {
        Class<?> clazz = ClassHelper.forName("int", testClassLoader);
        assertEquals(int.class, clazz);
    }

    @Test
    public void testForNameWithArray() throws ClassNotFoundException {
        Class<?> clazz = ClassHelper.forName("java.lang.String[]", testClassLoader);
        assertEquals(String[].class, clazz);
    }

    @Test
    public void testForNameWithInternalArray() throws ClassNotFoundException {
        Class<?> clazz = ClassHelper.forName("[Ljava.lang.String;", testClassLoader);
        assertEquals(String[].class, clazz);
    }

    @Test
    public void testResolvePrimitiveClassName() {
        assertNull(ClassHelper.resolvePrimitiveClassName("java.lang.String"));
        assertEquals(int.class, ClassHelper.resolvePrimitiveClassName("int"));
        assertEquals(double.class, ClassHelper.resolvePrimitiveClassName("double"));
    }

    @Test
    public void testToShortString() {
        List<String> list = new ArrayList<>();
        list.add("test");
        String shortString = ClassHelper.toShortString(list);
        assertTrue(shortString.startsWith("ArrayList@"));
//        assertTrue(shortString.endsWith("@"));
    }

    @Test
    public void testToShortStringWithNull() {
        assertEquals("null",ClassHelper.toShortString(null));
    }
}