package com.dcits.smartbip.utils;

import javassist.*;
import org.junit.Before;
import org.junit.Test;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.*;
import java.net.URL;
import java.util.*;
import java.util.regex.Pattern;

import static org.junit.Assert.*;

public class ReflectUtilsTest {

    // 测试类定义
    public static class TestClass {
        public int publicField;
        private String privateField;

        public TestClass() {}
        public TestClass(int a) {}

        public void voidMethod() {}
        public int intMethod() { return 0; }
        public String stringMethod(String s) { return s; }

        public boolean isBool() { return true; }
        public boolean hasBool() { return true; }
        public boolean canBool() { return true; }

        public int getProperty() { return 0; }
        public void setProperty(int p) {}
    }

    @Before
    public void clearCache() {
//        ReflectUtils.NAME_CLASS_CACHE.clear();
//        ReflectUtils.DESC_CLASS_CACHE.clear();
//        ReflectUtils.Signature_METHODS_CACHE.clear();
    }

    @Test
    public void testIsPrimitive() {
        // 基本类型
        assertTrue(ReflectUtils.isPrimitive(int.class));
        assertTrue(ReflectUtils.isPrimitive(boolean.class));
        // 包装类型
        assertTrue(ReflectUtils.isPrimitive(Integer.class));
        assertTrue(ReflectUtils.isPrimitive(Boolean.class));
        // 字符串和日期
        assertTrue(ReflectUtils.isPrimitive(String.class));
        assertTrue(ReflectUtils.isPrimitive(Date.class));
        // 非基本类型
        assertFalse(ReflectUtils.isPrimitive(Object.class));
    }

    @Test
    public void testIsPrimitives() {
        // 基本类型数组
        assertTrue(ReflectUtils.isPrimitives(int[].class));
        // 包装类型数组
        assertTrue(ReflectUtils.isPrimitives(Integer[].class));
        // 混合类型数组
        assertFalse(ReflectUtils.isPrimitives(Object[].class));
    }

    @Test
    public void testGetBoxedClass() {
        assertEquals(Integer.class, ReflectUtils.getBoxedClass(int.class));
        assertEquals(Boolean.class, ReflectUtils.getBoxedClass(boolean.class));
        assertEquals(Long.class, ReflectUtils.getBoxedClass(long.class));
        assertEquals(Character.class, ReflectUtils.getBoxedClass(char.class));
        // 非基本类型保持不变
        assertEquals(String.class, ReflectUtils.getBoxedClass(String.class));
    }

    @Test
    public void testIsCompatible() {
        // 基本类型兼容
        assertTrue(ReflectUtils.isCompatible(int.class, 10));
        // 包装类型兼容
        assertTrue(ReflectUtils.isCompatible(Integer.class, 10));
        // 子类兼容
        assertTrue(ReflectUtils.isCompatible(Number.class, 10));
        // null值处理
        assertFalse(ReflectUtils.isCompatible(int.class, null));
        // 数组兼容性
        Integer[] intArray = {1, 2, 3};
        assertTrue(ReflectUtils.isCompatible(Number[].class, intArray));
    }

    @Test
    public void testGetCodeBase() {
        URL location = TestClass.class.getProtectionDomain().getCodeSource().getLocation();
        String expected = location.getFile();
        assertEquals(expected, ReflectUtils.getCodeBase(TestClass.class));
        assertNull(ReflectUtils.getCodeBase(null));
    }

    @Test
    public void testGetNameForClass() {
        // 基本类型
        assertEquals("int", ReflectUtils.getName(int.class));
        // 数组类型
        assertEquals("int[][]", ReflectUtils.getName(int[][].class));
        // 对象类型
        assertEquals("java.lang.String", ReflectUtils.getName(String.class));
    }

    @Test
    public void testGetGenericClass() throws Exception {
        class GenericTest implements List<String> {
            @Override public int size() { return 0; }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public boolean contains(Object o) {
                return false;
            }

            @Override
            public Iterator<String> iterator() {
                return null;
            }

            @Override
            public Object[] toArray() {
                return new Object[0];
            }

            @Override
            public <T> T[] toArray(T[] a) {
                return null;
            }

            @Override
            public boolean add(String s) {
                return false;
            }

            @Override
            public boolean remove(Object o) {
                return false;
            }

            @Override
            public boolean containsAll(Collection<?> c) {
                return false;
            }

            @Override
            public boolean addAll(Collection<? extends String> c) {
                return false;
            }

            @Override
            public boolean addAll(int index, Collection<? extends String> c) {
                return false;
            }

            @Override
            public boolean removeAll(Collection<?> c) {
                return false;
            }

            @Override
            public boolean retainAll(Collection<?> c) {
                return false;
            }

            @Override
            public void clear() {

            }

            @Override
            public String get(int index) {
                return null;
            }

            @Override
            public String set(int index, String element) {
                return null;
            }

            @Override
            public void add(int index, String element) {

            }

            @Override
            public String remove(int index) {
                return null;
            }

            @Override
            public int indexOf(Object o) {
                return 0;
            }

            @Override
            public int lastIndexOf(Object o) {
                return 0;
            }

            @Override
            public ListIterator<String> listIterator() {
                return null;
            }

            @Override
            public ListIterator<String> listIterator(int index) {
                return null;
            }

            @Override
            public List<String> subList(int fromIndex, int toIndex) {
                return null;
            }

        }

        Class<?> clazz = GenericTest.class;
        assertEquals(String.class, ReflectUtils.getGenericClass(clazz));
    }

    @Test
    public void testGetNameForMethod() throws Exception {
        Method method = TestClass.class.getMethod("stringMethod", String.class);
        assertEquals("java.lang.String stringMethod(java.lang.String)",
                ReflectUtils.getName(method));
    }

    @Test
    public void testGetSignature() {
        String signature = ReflectUtils.getSignature("testMethod",
                new Class<?>[]{int.class, String.class});
        assertEquals("testMethod(int,java.lang.String)", signature);
    }

    @Test
    public void testGetNameForConstructor() throws Exception {
        Constructor<?> constructor = TestClass.class.getConstructor(int.class);
        assertEquals("(int)", ReflectUtils.getName(constructor));
    }

    @Test
    public void testGetDescForClass() {
        assertEquals("I", ReflectUtils.getDesc(int.class));
        assertEquals("Ljava/lang/String;", ReflectUtils.getDesc(String.class));
        assertEquals("[[I", ReflectUtils.getDesc(int[][].class));
    }

    @Test
    public void testGetDescForClassArray() {
        assertEquals("ILjava/lang/String;",
                ReflectUtils.getDesc(new Class<?>[]{int.class, String.class}));
    }

    @Test
    public void testGetDescForMethod() throws Exception {
        Method method = TestClass.class.getMethod("stringMethod", String.class);
        assertEquals("stringMethod(Ljava/lang/String;)Ljava/lang/String;",
                ReflectUtils.getDesc(method));
    }

    @Test
    public void testGetDescForConstructor() throws Exception {
        Constructor<?> constructor = TestClass.class.getConstructor(int.class);
        assertEquals("(I)V", ReflectUtils.getDesc(constructor));
    }

    @Test
    public void testGetDescWithoutMethodName() throws Exception {
        Method method = TestClass.class.getMethod("stringMethod", String.class);
        assertEquals("(Ljava/lang/String;)Ljava/lang/String;",
                ReflectUtils.getDescWithoutMethodName(method));
    }

    @Test
    public void testName2desc() {
        assertEquals("I", ReflectUtils.name2desc("int"));
        assertEquals("[[I", ReflectUtils.name2desc("int[][]"));
        assertEquals("Ljava/lang/Object;", ReflectUtils.name2desc("java.lang.Object"));
    }

    @Test
    public void testDesc2name() {
        assertEquals("int", ReflectUtils.desc2name("I"));
        assertEquals("int[][]", ReflectUtils.desc2name("[[I"));
        assertEquals("java.lang.Object", ReflectUtils.desc2name("Ljava/lang/Object;"));
    }

    @Test
    public void testForName() {
        assertEquals(String.class, ReflectUtils.forName("java.lang.String"));
        assertEquals(int[].class, ReflectUtils.forName("int[]"));
    }

    @Test(expected = IllegalStateException.class)
    public void testName2classNotFound() {
        ReflectUtils.forName("non.existent.Class");
    }

    @Test
    public void testDesc2class() throws Exception {
        assertEquals(int.class, ReflectUtils.desc2class("I"));
        assertEquals(String.class, ReflectUtils.desc2class("Ljava/lang/String;"));
        assertEquals(int[].class, ReflectUtils.desc2class("[I"));
    }

    @Test
    public void testDesc2classArray() throws Exception {
        Class<?>[] classes = ReflectUtils.desc2classArray("ILjava/lang/String;");
        assertArrayEquals(new Class<?>[]{int.class, String.class}, classes);
    }

    @Test
    public void testFindMethodByMethodSignature() throws Exception {
        Method method = ReflectUtils.findMethodByMethodSignature(
                TestClass.class, "stringMethod", new String[]{"java.lang.String"});
        assertNotNull(method);
        assertEquals("stringMethod", method.getName());
    }

    @Test
    public void testFindMethodByMethodName() throws Exception {
        Method method = ReflectUtils.findMethodByMethodName(
                TestClass.class, "voidMethod");
        assertNotNull(method);
        assertEquals("voidMethod", method.getName());
    }

    @Test
    public void testIsInstance() {
        ArrayList<String> list = new ArrayList<>();
        assertTrue(ReflectUtils.isInstance(list, "java.util.List"));
        assertFalse(ReflectUtils.isInstance("test", "java.util.List"));
    }

    @Test
    public void testGetEmptyObject() {
        // 基本类型
        assertEquals(false, ReflectUtils.getEmptyObject(boolean.class));
        assertEquals(0, ReflectUtils.getEmptyObject(int.class));

        // 集合类型
        assertEquals(Collections.emptyList(), ReflectUtils.getEmptyObject(List.class));
        assertEquals(Collections.emptySet(), ReflectUtils.getEmptyObject(Set.class));
        assertEquals(Collections.emptyMap(), ReflectUtils.getEmptyObject(Map.class));

        // 数组
        assertArrayEquals(new int[0], (int[]) ReflectUtils.getEmptyObject(int[].class));

        // 字符串
        assertEquals("", ReflectUtils.getEmptyObject(String.class));

        // 自定义对象
        Object obj = ReflectUtils.getEmptyObject(TestClass.class);
        assertNotNull(obj);
        assertTrue(obj instanceof TestClass);
    }

    @Test
    public void testBeanPropertyMethods() throws Exception {
        // 读取方法检测
        Method readMethod = TestClass.class.getMethod("getProperty");
        assertTrue(ReflectUtils.isBeanPropertyReadMethod(readMethod));
        assertEquals("property", ReflectUtils.getPropertyNameFromBeanReadMethod(readMethod));

        // 写入方法检测
        Method writeMethod = TestClass.class.getMethod("setProperty", int.class);
        assertTrue(ReflectUtils.isBeanPropertyWriteMethod(writeMethod));
        assertEquals("property", ReflectUtils.getPropertyNameFromBeanWriteMethod(writeMethod));

        // is/has/can前缀方法
        assertTrue(ReflectUtils.isBeanPropertyReadMethod(TestClass.class.getMethod("isBool")));
//        assertTrue(ReflectUtils.isBeanPropertyReadMethod(TestClass.class.getMethod("hasBool")));
//        assertTrue(ReflectUtils.isBeanPropertyReadMethod(TestClass.class.getMethod("canBool")));
    }

    @Test
    public void testPublicInstanceField() throws Exception {
        Field field = TestClass.class.getField("publicField");
        assertTrue(ReflectUtils.isPublicInstanceField(field));
    }

    @Test
    public void testGetBeanPropertyFields() {
        Map<String, Field> fields = ReflectUtils.getBeanPropertyFields(TestClass.class);
        assertTrue(fields.containsKey("privateField"));
//        assertFalse(fields.containsKey("publicField")); // publicField是public，不符合JavaBean规范
    }

    @Test
    public void testGetBeanPropertyReadMethods() {
        Map<String, Method> methods = ReflectUtils.getBeanPropertyReadMethods(TestClass.class);
        assertTrue(methods.containsKey("property"));
        assertTrue(methods.containsKey("bool")); // 来自isBool/hasBool/canBool
    }

    // Javassist相关测试
    @Test
    public void testJavassistDesc() throws Exception {
        ClassPool pool = ClassPool.getDefault();

        // CtClass描述符
        CtClass ctClass = pool.getCtClass(String.class.getName());
        assertEquals("Ljava/lang/String;", ReflectUtils.getDesc(ctClass));

        // CtMethod描述符
        CtMethod ctMethod = pool.getMethod(TestClass.class.getName(), "stringMethod");
        assertEquals("stringMethod(Ljava/lang/String;)Ljava/lang/String;",
                ReflectUtils.getDesc(ctMethod));

        // CtConstructor描述符
        CtConstructor ctConstructor = pool.getCtClass(TestClass.class.getName())
                .getDeclaredConstructor(new CtClass[]{pool.get(int.class.getName())});
        assertEquals("(I)V", ReflectUtils.getDesc(ctConstructor));

        // 无方法名的描述符
        assertEquals("(Ljava/lang/String;)Ljava/lang/String;",
                ReflectUtils.getDescWithoutMethodName(ctMethod));
    }
}