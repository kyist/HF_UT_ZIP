package com.dcits.smartbip.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import org.junit.Test;
import org.powermock.core.classloader.annotations.PowerMockIgnore;

import java.io.File;
import java.io.IOException;

/**
 * @Classname FileUtilForEdaTest
 * @Description TODO
 * @Author 45410663
 * @Date 2025/3/2 19:51
 */
@PowerMockIgnore({"javax.management.*","org.apache.logging.*"})
public class FileUtilForEdaTest {

    @Test
    public void backAndWriteProcessConfig_CreatesBackupAndWritesData() {
        String srcFilePath = "src/test/resources/testConfig.txt";
        String destFilePath = "src/test/resources/testConfigBackup.txt";
        String data = "test data";

        FileUtilForEda.backAndWriteProcessConfig(srcFilePath, destFilePath, data);

        assertThat(new File(destFilePath)).exists();
        assertThat(new File(srcFilePath)).hasContent(data);
    }

    @Test
    public void backAndWriteProcessConfig_ThrowsIOException() {
        String srcFilePath = "invalidPath/testConfig.txt";
        String destFilePath = "invalidPath/testConfigBackup.txt";
        String data = "test data";

        FileUtilForEda.backAndWriteProcessConfig(srcFilePath, destFilePath, data);
    }

    @Test
    public void writeToConfig_WritesDataToFile() {
        String srcFilePath = "src/test/resources/testConfig.txt";
        String data = "test data";

        FileUtilForEda.writeToConfig(srcFilePath, data);

        assertThat(new File(srcFilePath)).hasContent(data);
    }

    @Test
    public void writeToConfig_ThrowsIOException() {
        String srcFilePath = "invalidPath/testConfig.txt";
        String data = "test data";

       FileUtilForEda.writeToConfig(srcFilePath, data);
    }

    @Test
    public void backAndWriteConfig_CreatesBackupAndWritesData() {
        String sourceFilePath = "src/test/resources/testConfig.txt";
        String backFilePath = "src/test/resources/testConfigBackup.txt";
        String data = "test data";

        FileUtilForEda.backAndWriteConfig(sourceFilePath, backFilePath, data);

        assertThat(new File(backFilePath)).exists();
        assertThat(new File(sourceFilePath)).hasContent(data);
    }

    @Test
    public void backAndWriteConfig_ThrowsIOException() {
        String sourceFilePath = "invalidPath/testConfig.txt";
        String backFilePath = "invalidPath/testConfigBackup.txt";
        String data = "test data";

        FileUtilForEda.backAndWriteConfig(sourceFilePath, backFilePath, data);
    }

    @Test
    public void getFileFromCL_ReturnsFile() {
        File file = FileUtilForEda.getFileFromCL("testConfig.txt");

        assertThat(file).exists();
    }

    @Test
    public void getFileFromCL_ReturnsNullForInvalidPath() {
        File file = FileUtilForEda.getFileFromCL("invalidPath.txt");

        assertThat(file).isNull();
    }

    @Test
    public void getFileFromInstallPath_ReturnsFile() {
        System.setProperty("smartbip.install", "src/test/resources");
        File file = FileUtilForEda.getFileFromInstallPath();

        System.out.println(file.getAbsolutePath());
    }

    @Test
    public void getFromJar_ReturnsFile() {
        System.setProperty("smartbip.install", "src/test/resources");
        File file = FileUtilForEda.getFromJar("testConfig.txt");


    }

    @Test
    public void getFromConfigs_ReturnsFile() {
        System.setProperty("smartbip.install", "src/test/resources");
        File file = FileUtilForEda.getFromConfigs("testConfig.txt");


    }

    @Test
    public void getConfigPath_ReturnsPath() {
        System.setProperty("smartbip.install", "src/test/resources");
        String path = FileUtilForEda.getConfigPath();
        System.out.println(path);
    }

    @Test
    public void getJarPath_ReturnsPath() {
        System.setProperty("smartbip.install", "src/test/resources");
        String path = FileUtilForEda.getJarPath();
        System.out.println(path);
//        assertThat(path).isEqualTo("src/test/resources/jar");
    }

    @Test
    public void getRepositoryPath_ReturnsPath() {
        System.setProperty("smartbip.install", "src/test/resources");
        String path = FileUtilForEda.getRepositoryPath();
        System.out.println(path);
//        assertThat(path).isEqualTo("src/test/resources/jar/repository");
    }

}
