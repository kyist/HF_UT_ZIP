package com.dcits.smartbip.utils;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class IncrementNumberTest {

    private IncrementNumber incrementNumberUnderTest;

    @Before
    public void setUp() throws Exception {
        incrementNumberUnderTest = new IncrementNumber();
    }

    @Test
    public void testGetInstance() throws Exception {
        // Setup
        // Run the test
        final IncrementNumber result = IncrementNumber.getInstance();

        // Verify the results
    }

    @Test
    public void testMaxNumGetterAndSetter() {
        final int maxNum = 0;
        incrementNumberUnderTest.setMaxNum(maxNum);
        assertThat(incrementNumberUnderTest.getMaxNum()).isEqualTo(maxNum);
    }
}
