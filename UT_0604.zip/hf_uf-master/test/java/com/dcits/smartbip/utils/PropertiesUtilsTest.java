package com.dcits.smartbip.utils;

import org.junit.Test;

import java.util.HashMap;

import static org.assertj.core.api.Assertions.assertThat;

public class PropertiesUtilsTest {

    @Test
    public void testGetProductionAndDLIYWH() {
        // Setup
        final HashMap<String, String> expectedResult = new HashMap<>();

        // Run the test
        final HashMap<String, String> result = PropertiesUtils.getProductionAndDLIYWH();

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }

    @Test
    public void testGetReSignRetCode() {
        PropertiesUtils.getReSignRetCode("seviceId");
        PropertiesUtils.getReSignRetCode("seviceId");
    }

    @Test
    public void testGetSignOffRetCode() {
       PropertiesUtils.getSignOffRetCode("seviceId");
       PropertiesUtils.getSignOffRetCode("seviceId");
    }

    @Test
    public void testGetProductionAcctSrlNo() {
        // Setup
        final HashMap<String, String> expectedResult = new HashMap<>();

        // Run the test
        final HashMap<String, String> result = PropertiesUtils.getProductionAcctSrlNo();

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }

    @Test
    public void testGetMUBIAOXT() {
        // Setup
        final HashMap<String, String> expectedResult = new HashMap<>();

        // Run the test
        final HashMap<String, String> result = PropertiesUtils.getMUBIAOXT();

        // Verify the results
        assertThat(result).isEqualTo(expectedResult);
    }
}
