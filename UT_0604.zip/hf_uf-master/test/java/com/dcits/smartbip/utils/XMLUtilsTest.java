package com.dcits.smartbip.utils;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class XMLUtilsTest {

    @Test
    public void testGetDocFromBytes() throws Exception {
        // 创建一个简单的 XML 字符串
        String xmlContent = "<root><child>text</child></root>";
        byte[] xmlBytes = xmlContent.getBytes();

        // 调用方法
        Document doc = XMLUtils.getDocFromBytes(xmlBytes);

        // 验证结果
        Assertions.assertNotNull(doc, "Document should not be null");
        Assertions.assertEquals("root", doc.getRootElement().getName(), "Root element name should be 'root'");
    }

    @Test
    public void testGetDocFromFile() throws Exception {
        // 创建一个临时文件
        File tempFile = File.createTempFile("test", ".xml");
        tempFile.deleteOnExit();

        // 写入简单的 XML 内容
        String xmlContent = "<root><child>text</child></root>";
        try (FileWriter writer = new FileWriter(tempFile)) {
            writer.write(xmlContent);
        }

        // 调用方法
        Document doc = XMLUtils.getDocFromFile(tempFile);

        // 验证结果
        Assertions.assertNotNull(doc, "Document should not be null");
        Assertions.assertEquals("root", doc.getRootElement().getName(), "Root element name should be 'root'");
    }

    @Test
    public void testGetAttribute() throws Exception {
        // 创建一个简单的 XML 字符串
        String xmlContent = "<root attr='value'><child>text</child></root>";
        Document doc = XMLUtils.getDocFromBytes(xmlContent.getBytes());

        // 获取根节点
        Element root = doc.getRootElement();

        // 调用方法
        String attrValue = XMLUtils.getAttribute(root, "attr");

        // 验证结果
        Assertions.assertEquals("value", attrValue, "Attribute value should be 'value'");
    }

    @Test
    public void testGetChildElementText() throws Exception {
        // 创建一个简单的 XML 字符串
        String xmlContent = "<root><child>text</child></root>";
        Document doc = XMLUtils.getDocFromBytes(xmlContent.getBytes());

        // 获取根节点
        Element root = doc.getRootElement();

        // 调用方法
        String childText = XMLUtils.getChildElementText(root, "child");

        // 验证结果
        Assertions.assertEquals("text", childText, "Child element text should be 'text'");
    }

    @Test
    public void testGetChildElements() throws Exception {
        // 创建一个简单的 XML 字符串
        String xmlContent = "<root><child>text1</child><child>text2</child></root>";
        Document doc = XMLUtils.getDocFromBytes(xmlContent.getBytes());

        // 获取根节点
        Element root = doc.getRootElement();

        // 调用方法
        List<Element> childElements = XMLUtils.getChildElements(root, "child");

        // 验证结果
        Assertions.assertEquals(2, childElements.size(), "There should be 2 child elements");
        Assertions.assertEquals("text1", childElements.get(0).getText(), "First child text should be 'text1'");
        Assertions.assertEquals("text2", childElements.get(1).getText(), "Second child text should be 'text2'");
    }

    @Test
    public void testElementToMap() throws Exception {
        // 创建一个简单的 XML 字符串
        String xmlContent = "<root><child1>value1</child1><child2>value2</child2></root>";
        Document doc = XMLUtils.getDocFromBytes(xmlContent.getBytes());

        // 获取根节点
        Element root = doc.getRootElement();

        // 调用方法
        Map<String, String> map = XMLUtils.elementToMap(root);

        // 验证结果
        Assertions.assertEquals(2, map.size(), "Map should contain 2 entries");
        Assertions.assertEquals("value1", map.get("child1"), "Value for 'child1' should be 'value1'");
        Assertions.assertEquals("value2", map.get("child2"), "Value for 'child2' should be 'value2'");
    }

    @Test
    public void testSaveDocument() throws Exception {
        // 创建一个简单的 XML 文档
        Document doc = new SAXReader().read(new ByteArrayInputStream("<root><child>text</child></root>".getBytes()));

        // 创建一个临时文件
        File tempFile = File.createTempFile("test", ".xml");
        tempFile.deleteOnExit();

        // 调用方法
        XMLUtils.saveDocument(tempFile, doc);

        // 验证结果
        Assertions.assertTrue(tempFile.exists(), "File should exist after saving");
        Assertions.assertTrue(tempFile.length() > 0, "File should not be empty");
    }
}