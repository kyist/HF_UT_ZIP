package com.dcits.smartbip.utils;

import com.dcits.smartbip.runtime.model.IContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.HashMap;
import java.util.Map;

public class ContextUtilsTest {

    @Test
    public void testInitContextWithMap() {
        // 创建一个模拟的 IContext 实现
        MockContext mockContext = new MockContext();

        // 创建一个 Map
        Map<String, String> map = new HashMap<>();
        map.put("key1", "value1");
        map.put("key2", "value2");

        // 创建 ContextUtils 实例
        ContextUtils contextUtils = new ContextUtils();

        // 调用方法
        contextUtils.initContextWithMap(map, mockContext);

        // 验证结果
        Assertions.assertEquals("value1", mockContext.getValue("key1"), "Value for 'key1' should be 'value1'");
        Assertions.assertEquals("value2", mockContext.getValue("key2"), "Value for 'key2' should be 'value2'");
    }

    // 模拟 IContext 接口的实现
    private static class MockContext implements IContext {
        private Map<String, String> values = new HashMap<>();


        @Override
        public <T> T getValue(String key, Class<T> clazz) {
            return (T) values.get(key);
        }

        @Override
        public String getValue(String key) {
            return values.get(key);
        }

        @Override
        public void setValue(String key, Object value) {
            values.put(key, (String) value);
        }

        @Override
        public void setContext(IContext context) {

        }

        @Override
        public void clear() {

        }

        // 其他未实现的方法（根据 IContext 接口的实际定义补充）

    }
}