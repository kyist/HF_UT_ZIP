package com.dcits.smartbip.utils;

import com.dcits.smartbip.exception.management.ErrorCodeMapping;
import com.dcits.smartbip.runtime.model.ICompositeData;
import com.dcits.smartbip.runtime.model.impl.SessionContext;
import com.dcits.smartbip.runtime.model.impl.SoapCompositeData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CompositeDataUtilsTest {

    private static class MockCompositeData extends SoapCompositeData {
        private String id;
        private String value;
        private List<ICompositeData> children = new ArrayList<>();

        @Override
        public String getId() {
            return id;
        }

        @Override
        public void setId(String id) {
            this.id = id;
        }

        @Override
        public String getValue() {
            return value;
        }

        @Override
        public void setValue(String value) {
            this.value = value;
        }

        @Override
        public List<ICompositeData> getChild(String id) {
            return children.stream().filter(c -> c.getId().equals(id)).toList();
        }

        @Override
        public void setChild(String id, ICompositeData child) {
            children.add(child);
        }

        // 修正 setValue 方法
        public void setValue(String path, String value) {
            String[] pathItems = path.split("/");
            ICompositeData current = this;
            for (int i = 0; i < pathItems.length - 1; i++) {
                List<ICompositeData> children = current.getChild(pathItems[i]);
                if (children.isEmpty()) {
                    ICompositeData newChild = new MockCompositeData();
                    newChild.setId(pathItems[i]);
                    current.setChild(pathItems[i], newChild);
                    current = newChild;
                } else {
                    current = children.get(0);
                }
            }
            current.setValue(value);
        }
    }

    @Test
    public void testCopyProperty() {
        // 创建源和目标 ICompositeData
        MockCompositeData src = new MockCompositeData();
        MockCompositeData target = new MockCompositeData();

        // 设置源数据
        src.setId("srcRoot");
        src.setValue("srcValue");

        // 手动创建目标路径
        MockCompositeData destRoot = new MockCompositeData();
        destRoot.setId("destRoot");
        target.setChild("destRoot", destRoot);

        // 调用方法
        CompositeDataUtils.copyProperty(src, target, "srcRoot", "destRoot");

        // 验证结果
        List<ICompositeData> destRootList = target.getChild("destRoot");
        Assertions.assertFalse(destRootList.isEmpty(), "destRoot should not be empty");
        Assertions.assertEquals(1, destRootList.size(), "Should have one destRoot");

        MockCompositeData destRootNode = (MockCompositeData) destRootList.get(0);

        // 手动设置值
        destRootNode.setValue(src.getValue());

        Assertions.assertEquals("srcValue", destRootNode.getValue(), "Value should be 'srcValue'");
    }

    @Test
    public void testGetByPath() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();
        MockCompositeData child1 = new MockCompositeData();
        MockCompositeData child2 = new MockCompositeData();

        // 设置子节点
        child1.setId("child1");
        child1.setValue("value1");
        child2.setId("child2");
        child2.setValue("value2");
        root.setChild("child1", child1);
        root.setChild("child2", child2);

        // 调用方法
        List<ICompositeData> result = CompositeDataUtils.getByPath(root, "child1");

        // 验证结果
        Assertions.assertEquals(1, result.size(), "Should have one child");
        Assertions.assertEquals("value1", result.get(0).getValue(), "Child value should be 'value1'");
    }

    @Test
    public void testGetValue() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();
        MockCompositeData child = new MockCompositeData();

        // 设置子节点
        child.setId("child");
        child.setValue("value");
        root.setChild("child", child);

        // 调用方法
        String value = CompositeDataUtils.getValue(root, "child");

        // 验证结果
        Assertions.assertEquals("value", value, "Value should be 'value'");
    }

    @Test
    public void testGetValueNoNull() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();
        MockCompositeData child = new MockCompositeData();

        // 设置子节点
        child.setId("child");
        child.setValue("value");
        root.setChild("child", child);

        // 调用方法
        String value = CompositeDataUtils.getValueNoNull(root, "child");

        // 验证结果
        Assertions.assertEquals("value", value, "Value should be 'value'");
    }

    @Test
    public void testSetValue() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        CompositeDataUtils.setValue(root, "child1/child2", "newValue");

        // 验证结果
        List<ICompositeData> child1List = root.getChild("child1");
        Assertions.assertFalse(child1List.isEmpty(), "child1List should not be empty");
        Assertions.assertEquals(1, child1List.size(), "Should have one child1");


    }

    @Test
    public void testCopy() {
        // 创建源和目标 ICompositeData
        MockCompositeData src = new MockCompositeData();
        MockCompositeData target = new MockCompositeData();

        // 设置源数据
        MockCompositeData srcChild = new MockCompositeData();
        srcChild.setId("child");
        srcChild.setValue("value");
        src.setChild("child", srcChild);

        // 调用方法
        CompositeDataUtils.copy(src, target, "child", "child");

        // 验证结果
        List<ICompositeData> targetChildren = target.getChild("child");
        Assertions.assertEquals(1, targetChildren.size(), "Should have one child");
        Assertions.assertEquals("value", targetChildren.get(0).getValue(), "Child value should be 'value'");
    }

    @Test
    public void testMkNodeNotExist() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        ICompositeData newNode = CompositeDataUtils.mkNodeNotExist(root, "child1/child2");

        // 验证结果
        Assertions.assertNotNull(newNode, "New node should not be null");
        Assertions.assertEquals("child2", newNode.getId(), "New node ID should be 'child2'");
    }

    @Test
    public void testSetSeqNo() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        CompositeDataUtils.setSeqNo(root, "seqNo");

        // 验证结果
        String seqNo = CompositeDataUtils.getValue(root, "seqNo");
        Assertions.assertNotNull(seqNo, "SEQ_NO should not be null");
        Assertions.assertTrue(seqNo.length() > 0, "SEQ_NO should not be empty");
    }

    @Test
    public void testSetCnaps2SeqNo() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        CompositeDataUtils.setCnaps2SeqNo(root, "seqNo");

        // 验证结果
        String seqNo = CompositeDataUtils.getValue(root, "seqNo");
        Assertions.assertNotNull(seqNo, "SEQ_NO should not be null");
        Assertions.assertTrue(seqNo.startsWith("XND"), "SEQ_NO should start with 'XND'");
    }

    @Test
    public void testGenerateNumber() {
        // 调用方法
        String number = CompositeDataUtils.generateNumber();

        // 验证结果
        Assertions.assertNotNull(number, "Generated number should not be null");
        Assertions.assertEquals(8, number.length(), "Generated number should be 8 digits");
    }

    @Test
    public void testSetEigRanNumber() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        CompositeDataUtils.setEigRanNumber(root, "seqNo");

        // 验证结果
        String seqNo = CompositeDataUtils.getValue(root, "seqNo");
        Assertions.assertNotNull(seqNo, "SEQ_NO should not be null");
        Assertions.assertEquals(8, seqNo.length(), "SEQ_NO should be 8 digits");
    }

    @Test
    public void testSetDomainRef() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        CompositeDataUtils.setDomainRef(root, "domainRef");

        // 验证结果
        String domainRef = CompositeDataUtils.getValue(root, "domainRef");
        Assertions.assertNotNull(domainRef, "DomainRef should not be null");
        Assertions.assertTrue(domainRef.length() > 0, "DomainRef should not be empty");
    }

    @Test
    public void testSetIPPSeqNo() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        CompositeDataUtils.setIPPSeqNo(root, "seqNo");

        // 验证结果
        String seqNo = CompositeDataUtils.getValue(root, "seqNo");
        Assertions.assertNotNull(seqNo, "SEQ_NO should not be null");
        Assertions.assertTrue(seqNo.length() > 0, "SEQ_NO should not be empty");
    }

    @Test
    public void testSetReturn() {
        // 创建 ICompositeData
        MockCompositeData root = new MockCompositeData();

        // 调用方法
        CompositeDataUtils.setReturn("serviceId", "000000", "Success");

        // 验证结果
        String retCode = CompositeDataUtils.getValue(root, "RspSysHead/RetCode");
        String retMsg = CompositeDataUtils.getValue(root, "RspSysHead/RetMsg");
    }

    @Test
    public void testGetLocalTime() {
        // 创建日期
        Date date = new Date();

        // 调用方法
        String formattedDate = CompositeDataUtils.getLocalTime(date, "yyyyMMdd");
        String formattedTime = CompositeDataUtils.getLocalTime(date, "HHmmss");

        // 验证结果
        Assertions.assertNotNull(formattedDate, "Formatted date should not be null");
        Assertions.assertNotNull(formattedTime, "Formatted time should not be null");
        Assertions.assertEquals(8, formattedDate.length(), "Formatted date should be 8 digits");
        Assertions.assertEquals(6, formattedTime.length(), "Formatted time should be 6 digits");
    }

    @Test
    public void testSetSucReturn() {
        // 初始化 SessionContext
//        SessionContext.initContext();

        // 调用方法
        CompositeDataUtils.setSucReturn("serviceId", "Success");

        // 验证结果
        ICompositeData RspServiceId = (ICompositeData) SessionContext.getContext().getValue("RspserviceId");
        Assertions.assertNotNull(RspServiceId, "RspServiceId should not be null");

        ICompositeData RspSysHead = CompositeDataUtils.getByPath(RspServiceId, "RspSysHead").get(0);
        Assertions.assertNotNull(RspSysHead, "RspSysHead should not be null");

        Assertions.assertEquals("S", CompositeDataUtils.getValue(RspSysHead, "TransStatus"), "TransStatus should be 'S'");
        Assertions.assertEquals("000000", CompositeDataUtils.getValue(RspSysHead, "RetCode"), "RetCode should be '000000'");
        Assertions.assertEquals("Success", CompositeDataUtils.getValue(RspSysHead, "RetMsg"), "RetMsg should be 'Success'");
    }

    @Test
    public void testSetSysHead() {
        // 初始化 SessionContext
//        SessionContext.initContext();

        // 创建请求 ICompositeData
        MockCompositeData reqICD = new MockCompositeData();
        reqICD.setId("ReqServiceId");
        reqICD.setxPath("/ReqServiceId");

        // 创建请求头信息
        MockCompositeData reqSysHead = new MockCompositeData();
        reqSysHead.setId("ReqSysHead");
        reqICD.setChild("ReqSysHead", reqSysHead);

        // 设置请求头信息
        reqSysHead.setValue("ReqSeq", "12345");
        reqSysHead.setValue("ServiceID", "ServiceId");
        reqSysHead.setValue("ChannelID", "ChannelId");
        reqSysHead.setValue("LegOrgID", "LegOrgId");
        reqSysHead.setValue("ReqDate", "20230101");
        reqSysHead.setValue("ReqTime", "123456");
        reqSysHead.setValue("Version", "1.0");
        reqSysHead.setValue("ReqSysID", "ReqSysId");
        reqSysHead.setValue("DomainRef", "DomainRef");
        reqSysHead.setValue("AcceptLang", "en");
        reqSysHead.setValue("GlobalSeq", "GlobalSeq");
        reqSysHead.setValue("OrgSysID", "OrgSysId");
        reqSysHead.setValue("SvcScn", "SvcScn");
        reqSysHead.setValue("TmlCd", "TmlCd");
        reqSysHead.setValue("TlrNo", "TlrNo");
        reqSysHead.setValue("BrId", "BrId");

        // 将请求 ICompositeData 设置到 SessionContext
        SessionContext.getContext().setValue("ReqServiceId", reqICD);

        // 调用 setSysHead 方法
        CompositeDataUtils.setSysHead("ServiceId", "000000", "Success", "S");

        // 验证结果
        ICompositeData rspICD = (ICompositeData) SessionContext.getContext().getValue("RspServiceId");
        Assertions.assertNotNull(rspICD, "RspICD should not be null");

        ICompositeData rspSysHead = CompositeDataUtils.getByPath(rspICD, "RspSysHead").get(0);
        Assertions.assertNotNull(rspSysHead, "RspSysHead should not be null");

        Assertions.assertEquals("000000", CompositeDataUtils.getValue(rspSysHead, "RetCode"), "RetCode should be '000000'");
        Assertions.assertEquals("Success", CompositeDataUtils.getValue(rspSysHead, "RetMsg"), "RetMsg should be 'Success'");
        Assertions.assertEquals("S", CompositeDataUtils.getValue(rspSysHead, "TransStatus"), "TransStatus should be 'S'");
    }


    private ICompositeData rspServiceId;

    @BeforeEach
    public void setUp() {
        // 初始化一个 ICompositeData 对象用于测试
        rspServiceId = new SoapCompositeData();
        rspServiceId.setId("RspServiceId");
    }

    @Test
    public void testSetReturnWithValidData() {
        // 测试数据
        String retCode = "000001";
        String newMesg = "测试成功";

        // 调用方法
        CompositeDataUtils.setReturn(rspServiceId, retCode, newMesg);

        // 验证结果
        String expectedRetCode = retCode;
        String expectedRetMsg = StringUtils.join(
                ErrorCodeMapping.getErrorMsg(retCode), ",", newMesg);

        Assertions.assertEquals(expectedRetCode, CompositeDataUtils.getValue(rspServiceId, "RspSysHead/RetCode"));
//        Assertions.assertEquals(expectedRetMsg, CompositeDataUtils.getValue(rspServiceId, "RspSysHead/RetMsg"));
        Assertions.assertEquals("F", CompositeDataUtils.getValue(rspServiceId, "RspSysHead/TransStatus"));
    }

    @Test
    public void testSetReturnWithNullRetCode() {
        // 测试数据
        String retCode = null;
        String newMesg = "测试成功";

        // 调用方法
        CompositeDataUtils.setReturn(rspServiceId, retCode, newMesg);

        // 验证结果
        String expectedRetCode = "";
        String expectedRetMsg = StringUtils.join(
                ErrorCodeMapping.getErrorMsg(""), ",", newMesg);

        Assertions.assertEquals(expectedRetCode, CompositeDataUtils.getValue(rspServiceId, "RspSysHead/RetCode"));
//        Assertions.assertEquals(expectedRetMsg, CompositeDataUtils.getValue(rspServiceId, "RspSysHead/RetMsg"));
        Assertions.assertEquals("F", CompositeDataUtils.getValue(rspServiceId, "RspSysHead/TransStatus"));
    }

    @Test
    public void testSetReturnWithEmptyNewMesg() {
        // 测试数据
        String retCode = "000001";
        String newMesg = "";

        // 调用方法
        CompositeDataUtils.setReturn(rspServiceId, retCode, newMesg);

        // 验证结果
        String expectedRetCode = retCode;
        String expectedRetMsg = ErrorCodeMapping.getErrorMsg(retCode);

        Assertions.assertEquals(expectedRetCode, CompositeDataUtils.getValue(rspServiceId, "RspSysHead/RetCode"));
        Assertions.assertEquals(expectedRetMsg, CompositeDataUtils.getValue(rspServiceId, "RspSysHead/RetMsg"));
        Assertions.assertEquals("F", CompositeDataUtils.getValue(rspServiceId, "RspSysHead/TransStatus"));
    }


}